import { useEffect, useMemo, useState } from "react";
import { NvtkChart } from "@/components/chart/nvtk-chart";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  RANGE_PRESETS,
  candleTime,
  formatPct,
  formatPx,
  formatWhen,
  ohlc,
  type MarketBundle,
  type RangeId,
  type Zone,
} from "@/lib/market";

type Tab = "chart" | "research" | "logic";

function lastRange(n: number, bars: number) {
  if (bars <= 0 || bars >= n) return { start: 0, end: n };
  return { start: Math.max(0, n - bars), end: n };
}

function Stat({
  label,
  value,
  hint,
  tone,
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: "buy" | "sell" | "muted";
}) {
  return (
    <div className="min-w-0">
      <div className="text-xs font-medium tracking-wide text-muted uppercase">{label}</div>
      <div
        className={cn(
          "mt-1 font-mono text-lg font-medium tabular-nums leading-tight",
          tone === "buy" && "text-buy",
          tone === "sell" && "text-sell",
          tone === "muted" && "text-muted",
        )}
      >
        {value}
      </div>
      {hint ? <div className="mt-0.5 hidden text-xs text-subtle sm:block">{hint}</div> : null}
    </div>
  );
}

function ZoneRow({ z, onJump }: { z: Zone; onJump: (z: Zone) => void }) {
  const tone = z.dir === "BUY" ? "text-buy" : "text-sell";
  const status = !z.touched ? "no touch" : z.hit04 ? "≥0.4%" : "miss";
  return (
    <button
      type="button"
      onClick={() => onJump(z)}
      className="flex w-full items-start gap-3 rounded-sm px-2 py-2.5 text-left hover:bg-surface-2"
    >
      <span className={cn("mt-0.5 h-8 w-1 shrink-0 rounded-full", z.dir === "BUY" ? "bg-buy" : "bg-sell")} />
      <span className="min-w-0 flex-1">
        <span className="flex items-baseline justify-between gap-2">
          <span className={cn("font-medium", tone)}>{z.dir === "BUY" ? "Buy zone" : "Sell zone"}</span>
          <span className="font-mono text-xs tabular-nums text-muted">{formatPct(z.exp)}</span>
        </span>
        <span className="mt-0.5 block font-mono text-xs tabular-nums text-subtle">
          {formatPx(z.lo)}–{formatPx(z.hi)}
        </span>
        <span className="mt-0.5 block text-xs text-muted">
          {formatWhen(new Date(z.t0))} · {status}
        </span>
      </span>
    </button>
  );
}

export function Desk({ data }: { data: MarketBundle }) {
  const { candles, zones, metrics } = data;
  const n = candles.c.length;
  const last = ohlc(candles, n - 1);
  const prev = ohlc(candles, Math.max(0, n - 2));
  const chg = ((last.c - prev.c) / prev.c) * 100;

  const [tab, setTab] = useState<Tab>("chart");
  const [rangeId, setRangeId] = useState<RangeId>("1M");
  const [start, setStart] = useState(() => lastRange(n, 4500).start);
  const [end, setEnd] = useState(n);
  const [showBuy, setShowBuy] = useState(true);
  const [showSell, setShowSell] = useState(true);

  useEffect(() => {
    const preset = RANGE_PRESETS.find((p) => p.id === rangeId);
    if (!preset) return;
    const r = lastRange(n, preset.bars);
    setStart(r.start);
    setEnd(r.end);
  }, [rangeId, n]);

  const visibleZones = useMemo(() => {
    return zones
      .filter((z) => z.i1 >= start && z.i0 <= end)
      .filter((z) => (z.dir === "BUY" ? showBuy : showSell))
      .sort((a, b) => b.i0 - a.i0);
  }, [zones, start, end, showBuy, showSell]);

  const jump = (z: Zone) => {
    setTab("chart");
    const pad = 80;
    setStart(Math.max(0, z.i0 - pad));
    setEnd(Math.min(n, Math.max(z.i1 + pad, z.i0 + 220)));
  };

  const from = candleTime(candles, 0);
  const to = candleTime(candles, n - 1);

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <header className="border-b border-line px-4 py-3 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-medium tracking-[0.18em] text-muted uppercase">Symmetry Desk</p>
            <div className="mt-1 flex flex-wrap items-baseline gap-x-4 gap-y-1">
              <h1 className="font-sans text-2xl font-semibold tracking-tight sm:text-3xl">NVTK</h1>
              <span className="font-mono text-2xl tabular-nums">{formatPx(last.c)}</span>
              <span className={cn("font-mono text-sm tabular-nums", chg >= 0 ? "text-buy" : "text-sell")}>
                {formatPct(chg)}
              </span>
            </div>
            <p className="mt-1 text-sm text-muted">
              5-minute tape · {from.toLocaleDateString("en-GB")} – {to.toLocaleDateString("en-GB")} · MSK
            </p>
          </div>
          <nav className="flex rounded-md bg-surface p-1 shadow-[var(--shadow-border)]">
            {(
              [
                ["chart", "Chart"],
                ["research", "Research"],
                ["logic", "Logic"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setTab(id)}
                className={cn(
                  "h-10 min-w-20 rounded-sm px-3 text-sm font-medium transition-[background-color,color] duration-150",
                  tab === id ? "bg-surface-2 text-fg" : "text-muted hover:text-fg",
                )}
              >
                {label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <section className="grid grid-cols-2 gap-px border-b border-line bg-line sm:grid-cols-3 lg:grid-cols-6">
        <div className="bg-bg px-3 py-2 sm:px-6 sm:py-3">
          <Stat
            label="Hit after touch"
            value={`${metrics.hit04_given_touch.toFixed(1)}%`}
            hint="move ≥ 0.4% in zone direction"
            tone="buy"
          />
        </div>
        <div className="bg-bg px-3 py-2 sm:px-6 sm:py-3">
          <Stat label="Zones touched" value={`${metrics.touch_pct.toFixed(1)}%`} hint={`${metrics.touch} of ${metrics.n}`} />
        </div>
        <div className="hidden bg-bg px-3 py-2 sm:block sm:px-6 sm:py-3">
          <Stat label="Median target" value={formatPct(metrics.median_exp)} hint="projected EPA move" />
        </div>
        <div className="hidden bg-bg px-3 py-2 sm:block sm:px-6 sm:py-3">
          <Stat label="Payoff MFE/MAE" value={`${metrics.payoff.toFixed(2)}×`} hint={`MFE ${formatPct(metrics.avg_mfe)}`} />
        </div>
        <div className="bg-bg px-3 py-2 sm:px-6 sm:py-3">
          <Stat label="Buy zones" value={String(metrics.buy)} tone="buy" hint="green rectangles" />
        </div>
        <div className="bg-bg px-3 py-2 sm:px-6 sm:py-3">
          <Stat label="Sell zones" value={String(metrics.sell)} tone="sell" hint="red rectangles" />
        </div>
      </section>

      {tab === "chart" ? (
        <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
          <div className="flex min-h-0 min-w-0 flex-1 flex-col">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-3 py-2 sm:px-4">
              <div className="flex flex-wrap gap-1">
                {RANGE_PRESETS.map((p) => (
                  <Button
                    key={p.id}
                    variant={rangeId === p.id ? "outline" : "ghost"}
                    onClick={() => setRangeId(p.id)}
                  >
                    {p.label}
                  </Button>
                ))}
              </div>
              <div className="flex gap-1">
                <Button variant={showBuy ? "buy" : "ghost"} onClick={() => setShowBuy((v) => !v)}>
                  Buy
                </Button>
                <Button variant={showSell ? "sell" : "ghost"} onClick={() => setShowSell((v) => !v)}>
                  Sell
                </Button>
              </div>
            </div>
            <div className="min-h-[52vh] flex-1 p-2 sm:min-h-[28rem] sm:p-3">
              <NvtkChart
                pack={candles}
                zones={zones}
                start={start}
                end={end}
                showBuy={showBuy}
                showSell={showSell}
                onRange={(s, e) => {
                  setStart(s);
                  setEnd(e);
                }}
              />
            </div>
            <p className="px-4 pb-3 text-xs text-subtle">
              Green = buy zone at projected Wolfe point 5. Red = sell zone at the EPA / destination.
              Rectangles scale with impulse size. Scroll to zoom, drag to pan. Moves under ±0.4% are hidden.
            </p>
          </div>
          <aside className="flex max-h-[34vh] w-full shrink-0 flex-col border-t border-line lg:max-h-none lg:w-80 lg:border-t-0 lg:border-l">
            <div className="border-b border-line px-4 py-3">
              <h2 className="text-sm font-medium">Visible zones</h2>
              <p className="text-xs text-muted">{visibleZones.length} in this window</p>
            </div>
            <div className="flex-1 overflow-y-auto px-2 py-1">
              {visibleZones.length === 0 ? (
                <p className="px-2 py-6 text-sm text-muted">No ±0.4% zones in view. Zoom out or pan the tape.</p>
              ) : (
                visibleZones.slice(0, 80).map((z) => <ZoneRow key={z.id} z={z} onJump={jump} />)
              )}
            </div>
          </aside>
        </div>
      ) : null}

      {tab === "research" ? <Research metrics={metrics} /> : null}
      {tab === "logic" ? <Logic /> : null}
    </div>
  );
}

function Research({ metrics }: { metrics: MarketBundle["metrics"] }) {
  const months = Object.entries(metrics.monthly);
  return (
    <main className="mx-auto w-full max-w-4xl flex-1 px-4 py-8 sm:px-6">
      <h2 className="text-2xl font-semibold tracking-tight">What actually predicts NVTK</h2>
      <p className="mt-3 max-w-prose text-pretty text-muted">
        The original V2.6 script was an execution engine (buy-stop, trailing stop, TP1) sitting on a
        three-pivot ABCD projection. It was long-only, mixed trade management with pattern quality, and
        treated 0.80% as the first target even though typical favorable excursion on this name is closer
        to half a percent. The chart plotted entry triangles. None of that is how Wolfe symmetry works.
      </p>

      <ol className="mt-8 space-y-6">
        <li>
          <h3 className="font-medium">1. ABCD is not a Wolfe wave</h3>
          <p className="mt-1 text-pretty text-muted">
            V2.6 projected D = C + (B − A) from three ZigZag pivots. A Wolfe wave needs four confirmed
            pivots (1-2-3-4) so the 1–3 line can project point 5 and the 1–4 line can project the EPA.
            Without that geometry you get a harmonic completion, not channel symmetry.
          </p>
        </li>
        <li>
          <h3 className="font-medium">2. Prediction is a zone, not a fill</h3>
          <p className="mt-1 text-pretty text-muted">
            Stops, breakeven and trail settings change P&L; they do not change whether the pattern
            located a reversal. Scoring is now: after the zone is confirmed, does price visit it, and
            once it does, does it move at least 0.4% in the predicted direction before the zone invalidates
            on a close through the far edge.
          </p>
        </li>
        <li>
          <h3 className="font-medium">3. Both sides, 0.4% floor</h3>
          <p className="mt-1 text-pretty text-muted">
            NVTK mean-reverts in both directions on 5-minute structure. The model is symmetric: falling
            wedges print green buy rectangles, rising wedges print red sell rectangles. Anything with
            expected travel under 0.4% is dropped so the chart stays honest about tradable size.
          </p>
        </li>
        <li>
          <h3 className="font-medium">4. Convergence is the filter that matters</h3>
          <p className="mt-1 text-pretty text-muted">
            Across 96 configurations on 78,008 bars, raw ABCD at 0.60% ZigZag hit 71.7% after a touch —
            but it sprayed 2,919 overlapping boxes. Requiring the 1–3 and 2–4 channel to converge (true
            Wolfe wedge) cuts that to 579 zones with a 70.4% hit after touch. Almost the same edge, five
            times less noise. That is the production model.
          </p>
        </li>
      </ol>

      <h3 className="mt-10 font-medium">Year on tape</h3>
      <div className="mt-3 overflow-x-auto rounded-md bg-surface p-1 shadow-[var(--shadow-border)]">
        <table className="w-full min-w-[28rem] text-left text-sm">
          <thead className="text-xs tracking-wide text-muted uppercase">
            <tr>
              <th className="px-3 py-2 font-medium">Month</th>
              <th className="px-3 py-2 font-medium">Zones</th>
              <th className="px-3 py-2 font-medium">Touched</th>
              <th className="px-3 py-2 font-medium">Hit ≥0.4% | touch</th>
            </tr>
          </thead>
          <tbody className="font-mono tabular-nums">
            {months.map(([k, v]) => (
              <tr key={k} className="border-t border-line">
                <td className="px-3 py-2">{k}</td>
                <td className="px-3 py-2">{v.n}</td>
                <td className="px-3 py-2">{v.touch}</td>
                <td className={cn("px-3 py-2", v.hit_given_touch >= 60 ? "text-buy" : "text-fg")}>
                  {v.hit_given_touch.toFixed(1)}%
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <h3 className="mt-10 font-medium">Verdict</h3>
      <p className="mt-2 max-w-prose text-pretty text-muted">
        After a zone is touched, price delivers a 0.4%+ move in the predicted direction about seven times
        in ten (70.4% on 398 touches). About 69% of projected boxes are visited at all. Average favorable
        excursion is +0.49% versus −0.20% adverse (payoff 2.39×). Full EPA / destination is only reached
        17% of the time — the honest product of this pattern on NVTK is a 0.4–0.8% mean-reversion bounce,
        not a ride to the opposite rail. Worst months (Dec 2025, Apr 2026) still held above 42%. That is
        a usable map of location, not a guaranteed path.
      </p>
      <p className="mt-3 max-w-prose text-pretty text-muted">
        Baseline ABCD without Wolfe convergence is a hair more accurate on the 0.4% bounce (71.7%) and
        unusable on a chart. The symmetry model is the one worth drawing.
      </p>
    </main>
  );
}

function Logic() {
  return (
    <main className="mx-auto w-full max-w-4xl flex-1 px-4 py-8 sm:px-6">
      <h2 className="text-2xl font-semibold tracking-tight">Production model</h2>
      <p className="mt-3 max-w-prose text-pretty text-muted">
        Causal ZigZag 0.60%, four alternating pivots, converging 1–3 / 2–4 channel, entry band around the
        projected point 5 (width = 0.22 × AB, clamped), opposite-color destination around the 1–4 EPA.
        Invalidation on close through the zone. Minimum expected travel 0.40%.
      </p>
      <pre className="mt-6 overflow-x-auto rounded-md bg-surface p-4 font-mono text-xs leading-relaxed text-fg shadow-[var(--shadow-border)]">
        {CODE}
      </pre>
    </main>
  );
}

const CODE = `def build_causal_zigzag(df, deviation_pct=0.60):
    """Confirm a HIGH/LOW only after a reversal of deviation_pct. No lookahead."""
    ...

def wolfe_zones(pivots, min_move=0.40, half_ratio=0.22):
    for p1, p2, p3, p4 in windows_of_four(pivots):
        if not alternating(p1, p2, p3, p4):
            continue
        # Time symmetry: project point 5 at t3 + (t3 - t1)
        t5 = t3 + (t3 - t1)
        p5 = line(p1, p3, t5)          # 1-3 trendline
        epa = line(p1, p4, t_epa)      # 1-4 EPA
        if channel_width(t4) >= channel_width(t3):
            continue                   # must converge (wedge)
        direction = "BUY" if p1.kind == "LOW" else "SELL"
        move = (epa / p5 - 1) * 100 if direction == "BUY" else (1 - epa / p5) * 100
        if move < min_move:
            continue
        width = clamp(impulse_ab * half_ratio, 0.08%, 0.45%)
        yield Zone(direction, mid=p5, low=p5-width, high=p5+width,
                   target=epa, expected=move)

# Score on 78,008 NVTK 5m bars (2025-09-23 → 2026-09-28):
#   579 zones, 297 buy / 282 sell
#   68.7% of boxes are later touched
#   70.4% of touches move ≥ 0.4% in the predicted direction
#   payoff MFE/MAE = 2.39×`;
