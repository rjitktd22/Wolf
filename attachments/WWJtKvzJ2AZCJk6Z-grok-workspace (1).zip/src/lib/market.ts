export type CandlePack = {
  t0: string;
  barMin: number;
  t: number[];
  o: number[];
  h: number[];
  l: number[];
  c: number[];
  v: number[];
};

export type Zone = {
  id: number;
  dir: "BUY" | "SELL";
  t0: string;
  t1: string;
  i0: number;
  i1: number;
  lo: number;
  hi: number;
  mid: number;
  tlo: number;
  thi: number;
  tmid: number;
  exp: number;
  score: number;
  model: string;
  touched?: boolean;
  hit04?: boolean;
  hit_target?: boolean;
  mfe?: number;
};

export type MonthlyRow = {
  n: number;
  touch: number;
  hit: number;
  hit_given_touch: number;
};

export type Metrics = {
  n: number;
  touch: number;
  touch_pct: number;
  hit04: number;
  hit04_pct: number;
  hit04_given_touch: number;
  target: number;
  target_pct: number;
  target_given_touch: number;
  inval_first: number;
  avg_mfe: number;
  avg_mae: number;
  payoff: number;
  avg_exp: number;
  median_exp: number;
  buy: number;
  sell: number;
  model: string;
  name: string;
  deviation: number;
  min_move: number;
  half_ratio: number;
  bars: number;
  from: string;
  to: string;
  monthly: Record<string, MonthlyRow>;
  baseline_abcd: {
    n: number;
    hit04_given_touch: number;
    touch_pct: number;
    target_given_touch: number;
  };
};

export type MarketBundle = {
  candles: CandlePack;
  zones: Zone[];
  metrics: Metrics;
};

function px(tenths: number) {
  return tenths / 10;
}

export function candleTime(pack: CandlePack, i: number): Date {
  const t0 = new Date(pack.t0);
  return new Date(t0.getTime() + pack.t[i]! * 60_000);
}

export function ohlc(pack: CandlePack, i: number) {
  return {
    t: candleTime(pack, i),
    o: px(pack.o[i]!),
    h: px(pack.h[i]!),
    l: px(pack.l[i]!),
    c: px(pack.c[i]!),
    v: pack.v[i]!,
  };
}

export async function loadMarket(): Promise<MarketBundle> {
  const [candles, zones, metrics] = await Promise.all([
    fetch("/data/candles.json").then((r) => {
      if (!r.ok) throw new Error("Failed to load candles");
      return r.json() as Promise<CandlePack>;
    }),
    fetch("/data/zones.json").then((r) => {
      if (!r.ok) throw new Error("Failed to load zones");
      return r.json() as Promise<Zone[]>;
    }),
    fetch("/data/metrics.json").then((r) => {
      if (!r.ok) throw new Error("Failed to load metrics");
      return r.json() as Promise<Metrics>;
    }),
  ]);
  return { candles, zones, metrics };
}

export function formatPx(n: number, digits = 1) {
  return n.toLocaleString("ru-RU", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

export function formatPct(n: number, digits = 1) {
  const sign = n > 0 ? "+" : "";
  return `${sign}${n.toFixed(digits)}%`;
}

export function formatWhen(d: Date) {
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const hh = String(d.getHours()).padStart(2, "0");
  const mi = String(d.getMinutes()).padStart(2, "0");
  return `${dd}.${mm} ${hh}:${mi}`;
}

export function dayKey(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export const RANGE_PRESETS = [
  { id: "1D", bars: 220, label: "1D" },
  { id: "5D", bars: 1100, label: "5D" },
  { id: "1M", bars: 4500, label: "1M" },
  { id: "3M", bars: 14000, label: "3M" },
  { id: "6M", bars: 28000, label: "6M" },
  { id: "ALL", bars: 0, label: "All" },
] as const;

export type RangeId = (typeof RANGE_PRESETS)[number]["id"];
