#!/usr/bin/env python3
"""Export the winning NVTK Wolfe-symmetry zone model + compact candles."""
from __future__ import annotations

import json
import os
import shutil
import sys

sys.path.insert(0, "/workspace/research")
from zone_models import (
    load_df,
    build_causal_zigzag,
    zones_wolfe,
    zones_abcd,
    suppress_overlap,
    evaluate,
    realize_span,
    FORWARD_BARS,
    MIN_MOVE_PCT,
)
from refine_wolfe import tag_outcomes, monthly, dump_zones

OUT = "/workspace/research/out"
PUB = "/workspace/public/data"
os.makedirs(PUB, exist_ok=True)


def main():
    df = load_df()
    piv = build_causal_zigzag(df, 0.60)

    wolfe = zones_wolfe(
        piv, df,
        half_ratio=0.22,
        atr_mult=0.30,
        min_move=MIN_MOVE_PCT,
        require_converge=True,
        require_time_sym=False,
        sweet_overshoot=0.25,
        min_score=0.28,
    )
    wolfe = suppress_overlap(wolfe, 10)
    m_w = evaluate(df, wolfe)
    print("WOLFE4", m_w)

    abcd = zones_abcd(piv, df, 0.24, 0.40, 0.35, MIN_MOVE_PCT)
    abcd = suppress_overlap(abcd, 10)
    m_a = evaluate(df, abcd)
    print("ABCD  ", m_a)

    realize_span(df, wolfe)
    oc = tag_outcomes(df, wolfe)
    dump_zones(df, wolfe, os.path.join(OUT, "zones_production.json"), oc)

    mon = monthly(df, wolfe)
    metrics = {
        **m_w,
        "model": "wolfe4_converge",
        "name": "Wolfe 1-2-3-4 symmetry",
        "deviation": 0.60,
        "min_move": 0.40,
        "half_ratio": 0.22,
        "bars": int(len(df)),
        "from": df["time"].iloc[0].isoformat(),
        "to": df["time"].iloc[-1].isoformat(),
        "monthly": mon,
        "baseline_abcd": {
            "n": m_a["n"],
            "hit04_given_touch": m_a["hit04_given_touch"],
            "touch_pct": m_a["touch_pct"],
            "target_given_touch": m_a["target_given_touch"],
        },
        "notes": {
            "touch": "price later visited the projected zone",
            "hit04": "after touch, price moved ≥0.4% in the predicted direction before invalidation",
            "target": "price reached the opposite-color EPA / destination zone",
        },
    }
    with open(os.path.join(OUT, "metrics_production.json"), "w") as f:
        json.dump(metrics, f, indent=2)

    # compact candles (prices in tenths of a ruble, t = minutes from t0)
    t0 = df["time"].iloc[0]
    candles = {
        "t0": t0.isoformat(),
        "barMin": 5,
        "t": ((df["time"] - t0).dt.total_seconds() / 60.0).round().astype(int).tolist(),
        "o": (df["open"] * 10).round().astype(int).tolist(),
        "h": (df["high"] * 10).round().astype(int).tolist(),
        "l": (df["low"] * 10).round().astype(int).tolist(),
        "c": (df["close"] * 10).round().astype(int).tolist(),
        "v": df["volume"].astype(int).tolist(),
    }
    with open(os.path.join(OUT, "candles.json"), "w") as f:
        json.dump(candles, f, separators=(",", ":"))

    shutil.copy(os.path.join(OUT, "candles.json"), os.path.join(PUB, "candles.json"))
    shutil.copy(os.path.join(OUT, "zones_production.json"), os.path.join(PUB, "zones.json"))
    shutil.copy(os.path.join(OUT, "metrics_production.json"), os.path.join(PUB, "metrics.json"))
    print("published to", PUB)
    print("candles MB", os.path.getsize(os.path.join(PUB, "candles.json")) / 1e6)
    print("zones  KB", os.path.getsize(os.path.join(PUB, "zones.json")) / 1e3)

    # hit counts from outcomes
    hits = sum(1 for v in oc.values() if v["hit04"])
    touches = sum(1 for v in oc.values() if v["touched"])
    print(f"tagged hit04={hits}/{len(oc)}  touched={touches}")


if __name__ == "__main__":
    main()
