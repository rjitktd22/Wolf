#!/usr/bin/env python3
"""Refine Wolfe-symmetry zones: better targets, quality floor, monthly stability."""
from __future__ import annotations

import json
import math
import os
from collections import defaultdict
from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple

import numpy as np
import pandas as pd

from zone_models import (
    load_df, build_causal_zigzag, line_at, Pivot, Zone, _zone_width,
    suppress_overlap, evaluate, realize_span, MIN_MOVE_PCT, FORWARD_BARS,
)

OUT = "/workspace/research/out"


def zones_wolfe_v2(
    pivots: List[Pivot],
    df: pd.DataFrame,
    half_ratio: float,
    min_move: float,
    target_mode: str,
    require_converge: bool,
    max_atr_ratio: float,
    min_impulse_pct: float,
    max_t5_bars: int,
    session_only: bool,
) -> List[Zone]:
    atr = df["atr"].to_numpy()
    atr_ratio = df["atr_ratio"].to_numpy()
    hours = df["time"].dt.hour.to_numpy()
    minutes = df["time"].dt.minute.to_numpy()
    zones: List[Zone] = []
    zid = 0

    for i in range(3, len(pivots)):
        p1, p2, p3, p4 = pivots[i - 3], pivots[i - 2], pivots[i - 1], pivots[i]
        if not (p1.time < p2.time < p3.time < p4.time):
            continue
        if p1.kind == p2.kind or p2.kind == p3.kind or p3.kind == p4.kind:
            continue

        t1, t2, t3, t4 = p1.idx, p2.idx, p3.idx, p4.idx
        span13 = t3 - t1
        span24 = t4 - t2
        span34 = t4 - t3
        span12 = t2 - t1
        if span13 <= 2 or span24 <= 2 or span12 <= 1:
            continue

        t5 = t3 + span13
        if t5 <= t4:
            t5 = t4 + max(span34, max(span12 // 2, 4))
        if t5 - t4 > max_t5_bars:
            t5 = t4 + max_t5_bars

        ci = p4.confirmed_idx
        if ci >= len(df):
            continue
        if session_only:
            hm = hours[ci] * 60 + minutes[ci]
            # MOEX main + evening start; skip thin overnight 00:00-09:50
            if hm < 10 * 60 or hm >= 23 * 60 + 50:
                continue

        ar = atr_ratio[ci]
        if np.isfinite(ar) and max_atr_ratio > 0 and ar > max_atr_ratio:
            continue

        p5 = line_at(t1, p1.price, t3, p3.price, t5)
        t_epa = t5 + max(span24, span13 // 2, 8)
        t_epa = min(t_epa, t5 + 80)
        epa = line_at(t1, p1.price, t4, p4.price, t_epa)

        if p1.kind == "LOW":
            direction = "BUY"
        else:
            direction = "SELL"

        # channel width
        def ch_w(t):
            return abs(
                line_at(t1, p1.price, t3, p3.price, t)
                - line_at(t2, p2.price, t4, p4.price, t)
            )

        w_early, w_late = ch_w(t3), ch_w(t4)
        converging = w_early > 0 and w_late < w_early * 0.98
        if require_converge and not converging:
            continue

        impulse = abs(p2.price - p1.price)
        impulse_pct = impulse / max(p1.price, 1e-9) * 100.0
        if impulse_pct < min_impulse_pct:
            continue

        # structure sanity
        if direction == "BUY":
            if p3.price < p1.price * 0.975:
                continue
            if p4.price > p2.price * 1.012:
                continue
            if p5 >= p4.price:
                continue
        else:
            if p3.price > p1.price * 1.025:
                continue
            if p4.price < p2.price * 0.988:
                continue
            if p5 <= p4.price:
                continue

        # targets
        if target_mode == "epa":
            tgt = epa
        elif target_mode == "p2":
            tgt = p2.price
        elif target_mode == "blend":
            # conservative: 62% of the way from p5 toward the nearer of (epa, p2)
            far = p2.price if direction == "BUY" else p2.price
            # pick the closer valid target still ≥ min_move
            cands = [epa, p2.price]
            if direction == "BUY":
                cands = [x for x in cands if x > p5]
                tgt = min(cands) if cands else epa
            else:
                cands = [x for x in cands if x < p5]
                tgt = max(cands) if cands else epa
            # pull 0.72 of the way so target zone is reachable but still ≥0.4%
            tgt = p5 + 0.72 * (tgt - p5)
        elif target_mode == "bc040":
            # original ProfitGate exit: C + 0.4*BC, here C=p4, B=p3
            bc = p4.price - p3.price
            tgt = p4.price + 0.40 * bc if direction == "BUY" else p4.price + 0.40 * bc
        else:
            tgt = epa

        if direction == "BUY":
            move = (tgt / p5 - 1.0) * 100.0
        else:
            move = (1.0 - tgt / p5) * 100.0
        if move < min_move or p5 <= 0:
            continue

        w = _zone_width(impulse, p5, half_ratio, atr[ci], 0.28)
        tw = max(abs(tgt - p5) * 0.16, w * 0.9)

        conv_score = float(np.clip((w_early - w_late) / w_early, 0, 1)) if w_early > 0 else 0
        r12_34 = span34 / span12
        tscore = 1.0 - min(abs(math.log(max(r12_34, 1e-6))), 1.2) * 0.5
        move_score = float(np.clip(move / 1.3, 0, 1))
        score = 0.38 * conv_score + 0.28 * tscore + 0.34 * move_score

        zid += 1
        zones.append(Zone(
            zid, direction, ci, ci, min(len(df) - 1, max(t_epa, ci + 12)),
            p5 - w, p5 + w, p5,
            tgt - tw, tgt + tw, tgt,
            move, impulse, score, "wolfe_v2",
            p1.price, p2.price, p3.price, p4.price,
            t1, t2, t3, t4,
        ))
    return zones


def monthly(df, zones) -> Dict[str, Dict]:
    highs = df["high"].to_numpy()
    lows = df["low"].to_numpy()
    closes = df["close"].to_numpy()
    times = df["time"]
    by = defaultdict(lambda: {"n": 0, "touch": 0, "hit": 0})
    nbar = len(df)
    for z in zones:
        month = str(times.iloc[min(z.confirm_idx, nbar - 1)])[:7]
        by[month]["n"] += 1
        i0 = z.confirm_idx + 1
        i1 = min(nbar, i0 + FORWARD_BARS)
        touched = hit = False
        touch_px = z.z_mid
        for i in range(i0, i1):
            h, l, c = highs[i], lows[i], closes[i]
            if not touched:
                if h >= z.z_low and l <= z.z_high:
                    touched = True
                    touch_px = min(max(z.z_low, l), z.z_high) if z.direction == "BUY" else max(min(z.z_high, h), z.z_low)
                elif z.direction == "BUY" and c < z.z_low:
                    break
                elif z.direction == "SELL" and c > z.z_high:
                    break
                continue
            if z.direction == "BUY":
                if (h - touch_px) / touch_px * 100 >= MIN_MOVE_PCT:
                    hit = True
                    break
                if c < z.z_low:
                    break
            else:
                if (touch_px - l) / touch_px * 100 >= MIN_MOVE_PCT:
                    hit = True
                    break
                if c > z.z_high:
                    break
        by[month]["touch"] += int(touched)
        by[month]["hit"] += int(hit)
    out = {}
    for k, v in sorted(by.items()):
        ht = v["hit"] / v["touch"] * 100 if v["touch"] else 0
        out[k] = {**v, "hit_given_touch": round(ht, 1)}
    return out


def dump_zones(df, zs: List[Zone], path: str, outcomes=None):
    times = df["time"]
    rows = []
    for z in zs:
        rec = {
            "id": z.zone_id,
            "dir": z.direction,
            "t0": times.iloc[min(z.t0, len(df) - 1)].isoformat(),
            "t1": times.iloc[min(z.t1, len(df) - 1)].isoformat(),
            "i0": int(z.t0),
            "i1": int(min(z.t1, len(df) - 1)),
            "lo": round(float(z.z_low), 3),
            "hi": round(float(z.z_high), 3),
            "mid": round(float(z.z_mid), 3),
            "tlo": round(float(z.target_low), 3),
            "thi": round(float(z.target_high), 3),
            "tmid": round(float(z.target_mid), 3),
            "exp": round(float(z.expected_pct), 3),
            "score": round(float(z.score), 4),
            "model": z.model,
        }
        if outcomes and z.zone_id in outcomes:
            rec.update(outcomes[z.zone_id])
        rows.append(rec)
    with open(path, "w") as f:
        json.dump(rows, f)
    print("wrote", path, len(rows))


def tag_outcomes(df, zones) -> Dict[int, Dict]:
    highs = df["high"].to_numpy()
    lows = df["low"].to_numpy()
    closes = df["close"].to_numpy()
    nbar = len(df)
    out = {}
    for z in zones:
        i0 = z.confirm_idx + 1
        i1 = min(nbar, i0 + FORWARD_BARS)
        touched = hit = tgt = False
        mfe = 0.0
        touch_px = z.z_mid
        for i in range(i0, i1):
            h, l, c = highs[i], lows[i], closes[i]
            if not touched:
                if h >= z.z_low and l <= z.z_high:
                    touched = True
                    if z.direction == "BUY":
                        touch_px = min(max(l, z.z_low), z.z_high)
                    else:
                        touch_px = max(min(h, z.z_high), z.z_low)
                elif z.direction == "BUY" and c < z.z_low:
                    break
                elif z.direction == "SELL" and c > z.z_high:
                    break
                continue
            if z.direction == "BUY":
                mfe = max(mfe, (h - touch_px) / touch_px * 100)
                if mfe >= MIN_MOVE_PCT:
                    hit = True
                if h >= z.target_low:
                    tgt = True
                    break
                if c < z.z_low:
                    break
            else:
                mfe = max(mfe, (touch_px - l) / touch_px * 100)
                if mfe >= MIN_MOVE_PCT:
                    hit = True
                if l <= z.target_high:
                    tgt = True
                    break
                if c > z.z_high:
                    break
        out[z.zone_id] = {
            "touched": touched,
            "hit04": hit,
            "hit_target": tgt,
            "mfe": round(mfe, 3),
        }
    return out


def main():
    os.chdir("/workspace/research")
    df = load_df()
    print("bars", len(df))
    pivots = {d: build_causal_zigzag(df, d) for d in (0.50, 0.55, 0.60)}

    configs = []
    for d in (0.50, 0.55, 0.60):
        for tgt in ("epa", "p2", "blend", "bc040"):
            for conv in (True, False):
                for atr_cap in (2.5, 0):
                    for imp in (0.45, 0.60):
                        for sess in (True, False):
                            zs = zones_wolfe_v2(
                                pivots[d], df, 0.22, MIN_MOVE_PCT, tgt,
                                require_converge=conv, max_atr_ratio=atr_cap,
                                min_impulse_pct=imp, max_t5_bars=48,
                                session_only=sess,
                            )
                            zs = suppress_overlap(zs, 12)
                            m = evaluate(df, zs)
                            m.update(
                                model="wolfe_v2", dev=d, target=tgt,
                                conv=conv, atr_cap=atr_cap, imp=imp, sess=sess,
                            )
                            # quality rank: hit|touch primary, then target, balance, n in [250, 1200]
                            if m["n"] < 120:
                                rk = -1
                            else:
                                nfit = 1.0 - abs(m["n"] - 550) / 900.0
                                nfit = max(0.15, nfit)
                                bal = 1.0 - abs(m["buy"] - m["sell"]) / max(m["n"], 1)
                                rk = (
                                    0.42 * m["hit04_given_touch"] / 100
                                    + 0.20 * m["target_given_touch"] / 100
                                    + 0.14 * m["touch_pct"] / 100
                                    + 0.12 * min(m["payoff"] / 2.2, 1)
                                    + 0.07 * nfit
                                    + 0.05 * bal
                                )
                            m["rank"] = rk
                            configs.append((m, zs))

    configs.sort(key=lambda x: x[0]["rank"], reverse=True)
    print("\nTOP 25 refined Wolfe")
    print(f"{'#':>3} {'dev':>4} {'tgt':<6} {'cv':>2} {'atr':>4} {'imp':>4} {'se':>2} "
          f"{'n':>5} {'b':>4} {'s':>4} {'tch%':>6} {'hit|t':>6} {'tgt|t':>6} {'mfe':>5} {'pay':>5} {'rk':>6}")
    for i, (m, _) in enumerate(configs[:25], 1):
        print(f"{i:3d} {m['dev']:4.2f} {m['target']:<6} {int(m['conv']):2d} {m['atr_cap']:4.1f} "
              f"{m['imp']:4.2f} {int(m['sess']):2d} {m['n']:5d} {m['buy']:4d} {m['sell']:4d} "
              f"{m['touch_pct']:5.1f}% {m['hit04_given_touch']:5.1f}% {m['target_given_touch']:5.1f}% "
              f"{m['avg_mfe']:5.2f} {m['payoff']:5.2f} {m['rank']:6.3f}")

    best_m, best_z = configs[0]
    print("\nBEST", best_m)
    realize_span(df, best_z)
    oc = tag_outcomes(df, best_z)
    dump_zones(df, best_z, os.path.join(OUT, "zones_best.json"), oc)
    with open(os.path.join(OUT, "best_v2_metrics.json"), "w") as f:
        json.dump(best_m, f, indent=2)

    mon = monthly(df, best_z)
    print("\nMonthly hit|touch")
    for k, v in mon.items():
        print(f"  {k}  n={v['n']:4d}  touch={v['touch']:4d}  hit|t={v['hit_given_touch']:5.1f}%")
    with open(os.path.join(OUT, "monthly.json"), "w") as f:
        json.dump(mon, f, indent=2)

    # also dump a slightly denser runner-up if n is very low
    for m, zs in configs[1:]:
        if m["n"] >= 400 and m["hit04_given_touch"] >= 68:
            realize_span(df, zs)
            dump_zones(df, zs, os.path.join(OUT, "zones_alt.json"), tag_outcomes(df, zs))
            with open(os.path.join(OUT, "alt_metrics.json"), "w") as f:
                json.dump(m, f, indent=2)
            print("ALT", m)
            break

    with open(os.path.join(OUT, "refine_leaderboard.json"), "w") as f:
        json.dump([m for m, _ in configs], f, indent=2)


if __name__ == "__main__":
    main()
