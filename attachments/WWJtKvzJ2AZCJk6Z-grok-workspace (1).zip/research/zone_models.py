#!/usr/bin/env python3
"""NVTK zone-model bake-off: ABCD vs Wolfe symmetry vs confluence.

Causal ZigZag → projected BUY/SELL zones (≥0.4%). Score by:
  touch rate, hit ≥0.4% after touch (before invalidation), EPA/target reach,
  MFE/MAE, sample size.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import List, Optional, Dict, Tuple
import json
import math
import os

import numpy as np
import pandas as pd

DATA = "/workspace/attachments/scaner5_NVTK.xlsx"
OUT_DIR = "/workspace/research/out"
os.makedirs(OUT_DIR, exist_ok=True)

MIN_MOVE_PCT = 0.40
FORWARD_BARS = 48  # 4 hours on 5m
BAR_MINUTES = 5


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------

def load_df() -> pd.DataFrame:
    df = pd.read_excel(DATA)
    df["time"] = pd.to_datetime(df["DATE"])
    df = df.rename(
        columns={
            "candle_open": "open",
            "candle_close": "close",
            "candle_low": "low",
            "candle_high": "high",
            "candle_volume": "volume",
        }
    )
    df = (
        df.sort_values("time")
        .drop_duplicates("time")
        .reset_index(drop=True)
    )
    prev = df["close"].shift(1)
    tr = np.maximum(
        df["high"] - df["low"],
        np.maximum((df["high"] - prev).abs(), (df["low"] - prev).abs()),
    )
    df["atr"] = tr.rolling(14, min_periods=14).mean()
    df["atr_med"] = df["atr"].rolling(50, min_periods=50).median().shift(1)
    df["atr_ratio"] = df["atr"] / df["atr_med"]
    return df


# ---------------------------------------------------------------------------
# Causal ZigZag (matches the user's V2.6 logic)
# ---------------------------------------------------------------------------

@dataclass
class Pivot:
    idx: int
    time: pd.Timestamp
    price: float
    kind: str  # HIGH / LOW
    confirmed_idx: int
    confirmed_time: pd.Timestamp


def build_causal_zigzag(df: pd.DataFrame, deviation_pct: float) -> List[Pivot]:
    n = len(df)
    if n < 5:
        return []
    dev = deviation_pct / 100.0
    highs = df["high"].to_numpy(dtype=float)
    lows = df["low"].to_numpy(dtype=float)
    times = df["time"].to_numpy()

    pivots: List[Pivot] = []
    last_pivot_price = (highs[0] + lows[0]) / 2.0
    direction = None
    extreme_price = last_pivot_price
    extreme_idx = 0

    for i in range(1, n):
        high, low = highs[i], lows[i]
        if direction is None:
            if high >= last_pivot_price * (1.0 + dev):
                direction = "UP"
                extreme_price, extreme_idx = high, i
            elif low <= last_pivot_price * (1.0 - dev):
                direction = "DOWN"
                extreme_price, extreme_idx = low, i
            continue
        if direction == "UP":
            if high >= extreme_price:
                extreme_price, extreme_idx = high, i
            if low <= extreme_price * (1.0 - dev):
                pivots.append(
                    Pivot(extreme_idx, pd.Timestamp(times[extreme_idx]), extreme_price,
                          "HIGH", i, pd.Timestamp(times[i]))
                )
                last_pivot_price = extreme_price
                direction = "DOWN"
                extreme_price, extreme_idx = low, i
        else:
            if low <= extreme_price:
                extreme_price, extreme_idx = low, i
            if high >= extreme_price * (1.0 + dev):
                pivots.append(
                    Pivot(extreme_idx, pd.Timestamp(times[extreme_idx]), extreme_price,
                          "LOW", i, pd.Timestamp(times[i]))
                )
                last_pivot_price = extreme_price
                direction = "UP"
                extreme_price, extreme_idx = high, i

    clean: List[Pivot] = []
    for p in pivots:
        if clean and p.time <= clean[-1].time:
            continue
        if clean and p.kind == clean[-1].kind:
            if p.kind == "HIGH" and p.price > clean[-1].price:
                clean[-1] = p
            elif p.kind == "LOW" and p.price < clean[-1].price:
                clean[-1] = p
        else:
            clean.append(p)
    return clean


def line_at(t1, p1, t2, p2, t) -> float:
    dt = (t2 - t1)
    if dt == 0:
        return p1
    return p1 + (p2 - p1) * ((t - t1) / dt)


# ---------------------------------------------------------------------------
# Zone
# ---------------------------------------------------------------------------

@dataclass
class Zone:
    zone_id: int
    direction: str  # BUY / SELL
    confirm_idx: int
    t0: int  # start idx (inclusive)
    t1: int  # end idx hint (exclusive), filled later
    z_low: float
    z_high: float
    z_mid: float
    target_low: float
    target_high: float
    target_mid: float
    expected_pct: float
    impulse: float
    score: float
    model: str
    p1: float
    p2: float
    p3: float
    p4: Optional[float]
    t_p1: int
    t_p2: int
    t_p3: int
    t_p4: Optional[int]


def _zone_width(impulse: float, mid: float, half_ratio: float, atr: float, atr_mult: float) -> float:
    w = impulse * half_ratio
    if np.isfinite(atr) and atr_mult > 0:
        w = max(w, atr_mult * atr)
    # never wider than 0.45% of price (keeps rectangles tight but visible)
    w = min(w, mid * 0.0045)
    w = max(w, mid * 0.0008)  # min ~0.08% so the rect is visible
    return w


# ---------------------------------------------------------------------------
# Model A: original ABCD (3 pivots, D = C+AB)
# ---------------------------------------------------------------------------

def zones_abcd(
    pivots: List[Pivot],
    df: pd.DataFrame,
    half_ratio: float,
    exit_ext: float,
    atr_mult: float,
    min_move: float,
) -> List[Zone]:
    zones: List[Zone] = []
    atr = df["atr"].to_numpy()
    zid = 0
    for i in range(2, len(pivots)):
        a, b, c = pivots[i - 2], pivots[i - 1], pivots[i]
        if not (a.time < b.time < c.time):
            continue
        if not (a.kind != b.kind and b.kind != c.kind and a.kind == c.kind):
            continue
        ab = b.price - a.price
        impulse = abs(ab)
        if impulse <= 0:
            continue
        d = c.price + ab
        half = impulse * half_ratio
        if a.kind == "HIGH":  # BUY: projected low at D
            direction = "BUY"
            entry_mid = d
            bc = c.price - b.price
            exit_mid = c.price + exit_ext * bc
        else:
            direction = "SELL"
            entry_mid = d
            bc = b.price - c.price
            exit_mid = c.price - exit_ext * bc
        if direction == "BUY":
            move = (exit_mid / entry_mid - 1.0) * 100.0
        else:
            move = (1.0 - exit_mid / entry_mid) * 100.0
        if move < min_move or entry_mid <= 0:
            continue
        ai = min(c.confirmed_idx, len(df) - 1)
        w = _zone_width(impulse, entry_mid, half_ratio, atr[ai] if ai >= 0 else np.nan, atr_mult)
        tw = abs(exit_mid - entry_mid) * 0.20
        score = min(2.5, move / 0.4) * 0.4 + 0.3  # size-driven, no extra filters
        zid += 1
        zones.append(Zone(
            zid, direction, c.confirmed_idx, c.confirmed_idx, c.confirmed_idx + FORWARD_BARS,
            entry_mid - w, entry_mid + w, entry_mid,
            exit_mid - tw, exit_mid + tw, exit_mid,
            move, impulse, score, "abcd",
            a.price, b.price, c.price, None,
            a.idx, b.idx, c.idx, None,
        ))
    return zones


# ---------------------------------------------------------------------------
# Model B: 4-pivot Wolfe projection (true 1-2-3-4 → zone at 5, target EPA 1-4)
# ---------------------------------------------------------------------------

def zones_wolfe(
    pivots: List[Pivot],
    df: pd.DataFrame,
    half_ratio: float,
    atr_mult: float,
    min_move: float,
    require_converge: bool,
    require_time_sym: bool,
    sweet_overshoot: float,
    min_score: float,
) -> List[Zone]:
    """Bullish: 1L-2H-3L-4H, buy zone at 1-3 line (pt 5), sell/target = EPA 1-4.
    Bearish: inverse.
    """
    zones: List[Zone] = []
    atr = df["atr"].to_numpy()
    times_ns = df["time"].to_numpy()
    zid = 0
    for i in range(3, len(pivots)):
        p1, p2, p3, p4 = pivots[i - 3], pivots[i - 2], pivots[i - 1], pivots[i]
        if not (p1.time < p2.time < p3.time < p4.time):
            continue
        if p1.kind == p2.kind or p2.kind == p3.kind or p3.kind == p4.kind:
            continue

        t1, t2, t3, t4 = p1.idx, p2.idx, p3.idx, p4.idx
        # time symmetry of 1→3 vs projected 3→5: t5 = t3 + (t3 - t1)
        span13 = t3 - t1
        span24 = t4 - t2
        span34 = t4 - t3
        span12 = t2 - t1
        if span13 <= 1 or span24 <= 1:
            continue
        t5 = t3 + span13
        if t5 <= t4:
            t5 = t4 + max(span34, span12 // 2, 4)
        # cap projection
        t5 = min(t5, t4 + 72)
        t_epa = t5 + max(span24, span13 // 2, 8)
        t_epa = min(t_epa, t5 + 96)

        p5 = line_at(t1, p1.price, t3, p3.price, t5)
        epa = line_at(t1, p1.price, t4, p4.price, t_epa)

        if p1.kind == "LOW" and p2.kind == "HIGH":
            direction = "BUY"
        elif p1.kind == "HIGH" and p2.kind == "LOW":
            direction = "SELL"
        else:
            continue

        # Channel geometry
        slope13 = (p3.price - p1.price) / span13
        slope24 = (p4.price - p2.price) / span24
        # convergence: the two lines should approach (wedge), not expand
        # evaluate width at t3 vs t4
        w_at = lambda t: abs(
            line_at(t1, p1.price, t3, p3.price, t) - line_at(t2, p2.price, t4, p4.price, t)
        )
        w_early = w_at(t3)
        w_late = w_at(t4)
        converging = w_late < w_early * 0.97 and w_early > 0
        if require_converge and not converging:
            continue

        # Point 3 / 4 should stay "inside" the developing wedge
        if direction == "BUY":
            # 3 should be a higher-or-near low vs 1 (not a crash low far below)
            if p3.price < p1.price * (1.0 - 0.025):
                continue
            # 4 should not explode above 2 (expanding)
            if p4.price > p2.price * (1.0 + 0.012):
                continue
            # 5 should be at/under 3 (still testing support)
            if p5 > p3.price * (1.0 + sweet_overshoot / 100.0):
                continue
        else:
            if p3.price > p1.price * (1.0 + 0.025):
                continue
            if p4.price < p2.price * (1.0 - 0.012):
                continue
            if p5 < p3.price * (1.0 - sweet_overshoot / 100.0):
                continue

        if direction == "BUY":
            move = (epa / p5 - 1.0) * 100.0
        else:
            move = (1.0 - epa / p5) * 100.0
        if move < min_move or p5 <= 0 or epa <= 0:
            continue

        # Time symmetry 1-2 vs 3-4 and 1-3 vs 3-5
        r12_34 = (span34 / span12) if span12 else 9
        r13_35 = ((t5 - t3) / span13) if span13 else 9
        time_ok = 0.45 <= r12_34 <= 2.20 and 0.55 <= r13_35 <= 1.80
        if require_time_sym and not time_ok:
            continue

        impulse = abs(p2.price - p1.price)
        ai = min(p4.confirmed_idx, len(df) - 1)
        w = _zone_width(impulse, p5, half_ratio, atr[ai] if ai >= 0 else np.nan, atr_mult)
        tw = max(abs(epa - p5) * 0.18, w)

        # Score: confluence of move size, convergence, time symmetry, channel quality
        conv_score = 0.0
        if w_early > 0:
            conv_score = float(np.clip((w_early - w_late) / w_early, 0, 1))
        tscore = 1.0 - min(abs(math.log(max(r12_34, 1e-6))), 1.0) * 0.5
        tscore *= 1.0 - min(abs(math.log(max(r13_35, 1e-6))), 1.0) * 0.5
        move_score = float(np.clip(move / 1.2, 0, 1))
        score = 0.35 * conv_score + 0.30 * tscore + 0.35 * move_score
        if score < min_score:
            continue

        zid += 1
        # zone lives from p4 confirmation until projected EPA time
        t0 = p4.confirmed_idx
        t1_end = min(len(df) - 1, max(t_epa, t0 + 16))
        zones.append(Zone(
            zid, direction, t0, t0, t1_end,
            p5 - w, p5 + w, p5,
            epa - tw, epa + tw, epa,
            move, impulse, score, "wolfe",
            p1.price, p2.price, p3.price, p4.price,
            t1, t2, t3, t4,
        ))
    return zones


# ---------------------------------------------------------------------------
# Model C: confluence — ABCD D near Wolfe 1-3 projection
# ---------------------------------------------------------------------------

def zones_confluence(
    pivots: List[Pivot],
    df: pd.DataFrame,
    half_ratio: float,
    atr_mult: float,
    min_move: float,
    max_diverge_pct: float,
) -> List[Zone]:
    """After 4 pivots: ABCD D (from 2,3,4 as A,B,C) vs Wolfe 1-3 at t5.
    Keep only if they agree within max_diverge_pct.
    """
    zones: List[Zone] = []
    atr = df["atr"].to_numpy()
    zid = 0
    for i in range(3, len(pivots)):
        p1, p2, p3, p4 = pivots[i - 3], pivots[i - 2], pivots[i - 1], pivots[i]
        if not (p1.time < p2.time < p3.time < p4.time):
            continue
        if p1.kind == p2.kind or p2.kind == p3.kind:
            continue

        # ABCD using last 3: A=p2, B=p3, C=p4  → D = C + (B-A)
        a, b, c = p2, p3, p4
        ab = b.price - a.price
        impulse = abs(ab)
        if impulse <= 0:
            continue
        d_abcd = c.price + ab

        t1, t3, t4 = p1.idx, p3.idx, p4.idx
        span13 = t3 - t1
        if span13 <= 1:
            continue
        t5 = t3 + span13
        if t5 <= t4:
            t5 = t4 + max(t4 - t3, 4)
        t5 = min(t5, t4 + 72)
        p5_wolfe = line_at(t1, p1.price, t3, p3.price, t5)

        diverge = abs(d_abcd - p5_wolfe) / max(p5_wolfe, 1e-9) * 100.0
        if diverge > max_diverge_pct:
            continue

        mid = 0.5 * (d_abcd + p5_wolfe)
        t_epa = t5 + max(t4 - p2.idx, span13 // 2, 8)
        t_epa = min(t_epa, t5 + 96)
        epa = line_at(t1, p1.price, t4, p4.price, t_epa)

        if p1.kind == "LOW":
            direction = "BUY"
            move = (epa / mid - 1.0) * 100.0
        else:
            direction = "SELL"
            move = (1.0 - epa / mid) * 100.0
        if move < min_move:
            continue

        # extra: ABCD D and Wolfe 5 must be on the "right side" of current price
        if direction == "BUY" and mid >= p4.price:
            continue
        if direction == "SELL" and mid <= p4.price:
            continue

        ai = min(p4.confirmed_idx, len(df) - 1)
        w = _zone_width(impulse, mid, half_ratio, atr[ai] if ai >= 0 else np.nan, atr_mult)
        tw = max(abs(epa - mid) * 0.18, w)
        score = (1.0 - diverge / max_diverge_pct) * 0.5 + float(np.clip(move / 1.2, 0, 1)) * 0.5

        zid += 1
        t0 = p4.confirmed_idx
        t1_end = min(len(df) - 1, max(t_epa, t0 + 16))
        zones.append(Zone(
            zid, direction, t0, t0, t1_end,
            mid - w, mid + w, mid,
            epa - tw, epa + tw, epa,
            move, impulse, score, "confluence",
            p1.price, p2.price, p3.price, p4.price,
            p1.idx, p2.idx, p3.idx, p4.idx,
        ))
    return zones


# ---------------------------------------------------------------------------
# Model D: refined Wolfe — 5-point with point-5 already printed, zone at 5
# (reactive). Predictive test: after 5 confirms, does EPA get reached?
# ---------------------------------------------------------------------------

def zones_wolfe5_reactive(
    pivots: List[Pivot],
    df: pd.DataFrame,
    half_ratio: float,
    atr_mult: float,
    min_move: float,
    line_tol_pct: float,
) -> List[Zone]:
    zones: List[Zone] = []
    atr = df["atr"].to_numpy()
    zid = 0
    for i in range(4, len(pivots)):
        p1, p2, p3, p4, p5 = pivots[i - 4], pivots[i - 3], pivots[i - 2], pivots[i - 1], pivots[i]
        if p1.kind == p2.kind:
            continue
        t1, t3 = p1.idx, p3.idx
        if t3 == t1:
            continue
        line5 = line_at(t1, p1.price, t3, p3.price, p5.idx)
        dist = abs(p5.price - line5) / max(abs(line5), 1e-9) * 100.0
        if dist > line_tol_pct:
            continue

        t_epa = p5.idx + max(p4.idx - p2.idx, p3.idx - p1.idx, 8)
        t_epa = min(t_epa, p5.idx + 96)
        epa = line_at(p1.idx, p1.price, p4.idx, p4.price, t_epa)

        if p1.kind == "LOW":
            direction = "BUY"
            move = (epa / p5.price - 1.0) * 100.0
        else:
            direction = "SELL"
            move = (1.0 - epa / p5.price) * 100.0
        if move < min_move:
            continue

        w_early = abs(p3.price - line_at(p2.idx, p2.price, p4.idx, p4.price, p3.idx))
        w_late = abs(p5.price - line_at(p2.idx, p2.price, p4.idx, p4.price, p5.idx))
        conv = 1.0 if (w_early > 0 and w_late < w_early) else 0.3
        impulse = abs(p2.price - p1.price)
        ai = min(p5.confirmed_idx, len(df) - 1)
        w = _zone_width(impulse, p5.price, half_ratio, atr[ai] if ai >= 0 else np.nan, atr_mult)
        tw = max(abs(epa - p5.price) * 0.18, w)
        score = 0.4 * conv + 0.3 * (1.0 - dist / line_tol_pct) + 0.3 * float(np.clip(move / 1.2, 0, 1))

        zid += 1
        t0 = p5.confirmed_idx
        zones.append(Zone(
            zid, direction, t0, t0, min(len(df) - 1, t_epa),
            p5.price - w, p5.price + w, p5.price,
            epa - tw, epa + tw, epa,
            move, impulse, score, "wolfe5",
            p1.price, p2.price, p3.price, p4.price,
            p1.idx, p2.idx, p3.idx, p4.idx,
        ))
    return zones


# ---------------------------------------------------------------------------
# Evaluation (causal: only look AFTER confirm_idx)
# ---------------------------------------------------------------------------

def evaluate(df: pd.DataFrame, zones: List[Zone], forward: int = FORWARD_BARS) -> Dict:
    if not zones:
        return {
            "n": 0, "touch": 0, "touch_pct": 0, "hit04": 0, "hit04_pct": 0,
            "hit04_given_touch": 0, "target": 0, "target_given_touch": 0,
            "inval_first": 0, "avg_mfe": 0, "avg_mae": 0, "payoff": 0,
            "avg_exp": 0, "buy": 0, "sell": 0, "median_exp": 0,
        }
    highs = df["high"].to_numpy(dtype=float)
    lows = df["low"].to_numpy(dtype=float)
    closes = df["close"].to_numpy(dtype=float)
    nbar = len(df)

    touch = hit04 = target = inval_first = 0
    mfes, maes, exps = [], [], []
    buy = sell = 0

    for z in zones:
        i0 = z.confirm_idx + 1
        i1 = min(nbar, i0 + forward, z.t1 + 1 if z.t1 else i0 + forward)
        if i0 >= nbar or i1 <= i0:
            continue
        exps.append(z.expected_pct)
        if z.direction == "BUY":
            buy += 1
        else:
            sell += 1

        touched = False
        invalidated = False
        reached_04 = False
        reached_tg = False
        mfe = 0.0
        mae = 0.0
        touch_px = None

        for i in range(i0, i1):
            h, l, c = highs[i], lows[i], closes[i]
            if not touched:
                if h >= z.z_low and l <= z.z_high:
                    touched = True
                    touch_px = min(h, max(l, z.z_mid)) if z.direction == "BUY" else max(l, min(h, z.z_mid))
                    if z.direction == "BUY":
                        touch_px = min(l, z.z_high) if l < z.z_high else z.z_mid
                        touch_px = max(touch_px, z.z_low)
                    else:
                        touch_px = max(h, z.z_low) if h > z.z_low else z.z_mid
                        touch_px = min(touch_px, z.z_high)
                else:
                    # invalidate before touch if price blows through the zone
                    if z.direction == "BUY" and c < z.z_low:
                        invalidated = True
                        break
                    if z.direction == "SELL" and c > z.z_high:
                        invalidated = True
                        break
                    continue

            # after touch
            if z.direction == "BUY":
                mfe = max(mfe, (h - touch_px) / touch_px * 100.0)
                mae = min(mae, (l - touch_px) / touch_px * 100.0)
                if mfe >= MIN_MOVE_PCT:
                    reached_04 = True
                if h >= z.target_low:
                    reached_tg = True
                if c < z.z_low:
                    invalidated = True
                    break
            else:
                mfe = max(mfe, (touch_px - l) / touch_px * 100.0)
                mae = min(mae, (touch_px - h) / touch_px * 100.0)
                if mfe >= MIN_MOVE_PCT:
                    reached_04 = True
                if l <= z.target_high:
                    reached_tg = True
                if c > z.z_high:
                    invalidated = True
                    break
            if reached_tg:
                break

        if touched:
            touch += 1
        if reached_04:
            hit04 += 1
        if reached_tg:
            target += 1
        if invalidated and not reached_04:
            inval_first += 1
        mfes.append(mfe if touched else 0.0)
        maes.append(mae if touched else 0.0)

    n = len(zones)
    tp = touch / n * 100 if n else 0
    h4 = hit04 / n * 100 if n else 0
    h4t = hit04 / touch * 100 if touch else 0
    tgt = target / n * 100 if n else 0
    tgtt = target / touch * 100 if touch else 0
    avg_mfe = float(np.mean(mfes)) if mfes else 0
    avg_mae = float(np.mean(maes)) if maes else 0
    payoff = abs(avg_mfe / avg_mae) if avg_mae not in (0, 0.0) else 0
    return {
        "n": n,
        "touch": touch,
        "touch_pct": tp,
        "hit04": hit04,
        "hit04_pct": h4,
        "hit04_given_touch": h4t,
        "target": target,
        "target_pct": tgt,
        "target_given_touch": tgtt,
        "inval_first": inval_first,
        "avg_mfe": avg_mfe,
        "avg_mae": avg_mae,
        "payoff": payoff,
        "avg_exp": float(np.mean(exps)) if exps else 0,
        "median_exp": float(np.median(exps)) if exps else 0,
        "buy": buy,
        "sell": sell,
    }


def suppress_overlap(zones: List[Zone], min_gap_bars: int = 8) -> List[Zone]:
    """Keep higher-score zone when two same-direction zones overlap in time."""
    if not zones:
        return []
    ordered = sorted(zones, key=lambda z: (-z.score, z.confirm_idx))
    kept: List[Zone] = []
    for z in ordered:
        clash = False
        for k in kept:
            if z.direction != k.direction:
                continue
            if abs(z.confirm_idx - k.confirm_idx) < min_gap_bars:
                clash = True
                break
            # price overlap of mids within 0.15%
            if abs(z.z_mid - k.z_mid) / k.z_mid * 100 < 0.15 and abs(z.confirm_idx - k.confirm_idx) < 24:
                clash = True
                break
        if not clash:
            kept.append(z)
    kept.sort(key=lambda z: z.confirm_idx)
    # reindex ids
    for i, z in enumerate(kept, 1):
        z.zone_id = i
    return kept


# ---------------------------------------------------------------------------
# Fill actual t1 (invalidation / target / timeout) for drawing
# ---------------------------------------------------------------------------

def realize_span(df: pd.DataFrame, zones: List[Zone], forward: int = FORWARD_BARS) -> None:
    highs = df["high"].to_numpy(dtype=float)
    lows = df["low"].to_numpy(dtype=float)
    closes = df["close"].to_numpy(dtype=float)
    nbar = len(df)
    for z in zones:
        i0 = z.confirm_idx
        i1 = min(nbar, i0 + forward)
        end = i1 - 1
        touched = False
        for i in range(i0 + 1, i1):
            h, l, c = highs[i], lows[i], closes[i]
            if h >= z.z_low and l <= z.z_high:
                touched = True
            if z.direction == "BUY":
                if h >= z.target_low and touched:
                    end = i
                    break
                if c < z.z_low:
                    end = i
                    break
            else:
                if l <= z.target_high and touched:
                    end = i
                    break
                if c > z.z_high:
                    end = i
                    break
        z.t1 = max(end, z.confirm_idx + 6)


def composite(m: Dict) -> float:
    """Single ranking score. Emphasize conditional hit after touch + sample + target."""
    if m["n"] < 80:
        return -1.0
    # want enough trades, high hit given touch, decent target, not too noisy
    size = min(m["n"] / 400.0, 1.0)
    hit = m["hit04_given_touch"] / 100.0
    tgt = m["target_given_touch"] / 100.0
    touch = m["touch_pct"] / 100.0
    payoff = min(m["payoff"] / 2.0, 1.0)
    # penalize if almost no sells or buys (need both colors)
    bal = 1.0 - abs((m["buy"] - m["sell"]) / max(m["n"], 1))
    return 0.34 * hit + 0.18 * tgt + 0.14 * touch + 0.14 * payoff + 0.12 * size + 0.08 * bal


def main():
    print("Loading…")
    df = load_df()
    print(f"bars={len(df):,}  {df['time'].iloc[0]} → {df['time'].iloc[-1]}")

    grid = []
    deviations = [0.35, 0.40, 0.45, 0.50, 0.55, 0.60]
    halfs = [0.16, 0.20, 0.24]

    cache_piv = {d: build_causal_zigzag(df, d) for d in deviations}
    for d, p in cache_piv.items():
        print(f"  zigzag {d:.2f}% → {len(p)} pivots")

    # A. ABCD
    for d in deviations:
        for h in halfs:
            zs = zones_abcd(cache_piv[d], df, h, 0.40, 0.35, MIN_MOVE_PCT)
            zs = suppress_overlap(zs, 10)
            m = evaluate(df, zs)
            m.update(model="abcd", dev=d, half=h, extra="exit0.40")
            m["rank"] = composite(m)
            grid.append((m, zs))

    # B. Wolfe projected (strict / loose)
    for d in deviations:
        for h in [0.18, 0.22]:
            for conv in (True, False):
                for tsym in (True, False):
                    zs = zones_wolfe(
                        cache_piv[d], df, h, 0.30, MIN_MOVE_PCT,
                        require_converge=conv, require_time_sym=tsym,
                        sweet_overshoot=0.25, min_score=0.28,
                    )
                    zs = suppress_overlap(zs, 10)
                    m = evaluate(df, zs)
                    m.update(
                        model="wolfe4",
                        dev=d, half=h,
                        extra=f"conv={int(conv)} tsym={int(tsym)}",
                    )
                    m["rank"] = composite(m)
                    grid.append((m, zs))

    # C. Confluence
    for d in deviations:
        for div in (0.18, 0.28, 0.40):
            zs = zones_confluence(cache_piv[d], df, 0.20, 0.30, MIN_MOVE_PCT, div)
            zs = suppress_overlap(zs, 8)
            m = evaluate(df, zs)
            m.update(model="confluence", dev=d, half=0.20, extra=f"div≤{div}")
            m["rank"] = composite(m)
            grid.append((m, zs))

    # D. Reactive 5-point
    for d in deviations:
        for tol in (0.22, 0.35):
            zs = zones_wolfe5_reactive(cache_piv[d], df, 0.20, 0.30, MIN_MOVE_PCT, tol)
            zs = suppress_overlap(zs, 10)
            m = evaluate(df, zs)
            m.update(model="wolfe5", dev=d, half=0.20, extra=f"tol={tol}")
            m["rank"] = composite(m)
            grid.append((m, zs))

    grid.sort(key=lambda x: x[0]["rank"], reverse=True)

    print("\n" + "=" * 140)
    print(f"{'rk':>3} {'model':<12} {'dev':>5} {'half':>5} {'extra':<18} {'n':>5} "
          f"{'buy':>4} {'sell':>4} {'touch%':>7} {'hit|tch':>8} {'tgt|tch':>8} "
          f"{'mfe':>6} {'mae':>6} {'pay':>5} {'rank':>6}")
    print("=" * 140)
    for i, (m, _) in enumerate(grid[:40], 1):
        print(f"{i:3d} {m['model']:<12} {m['dev']:5.2f} {m['half']:5.2f} {m['extra']:<18} "
              f"{m['n']:5d} {m['buy']:4d} {m['sell']:4d} {m['touch_pct']:6.1f}% "
              f"{m['hit04_given_touch']:7.1f}% {m['target_given_touch']:7.1f}% "
              f"{m['avg_mfe']:6.2f} {m['avg_mae']:6.2f} {m['payoff']:5.2f} {m['rank']:6.3f}")

    # Best overall + best of each family
    best_m, best_z = grid[0]
    print("\nBEST:", {k: best_m[k] for k in best_m if k != 'rank'}, "rank", round(best_m["rank"], 3))

    families = {}
    for m, zs in grid:
        families.setdefault(m["model"], (m, zs))
    print("\nBest per family:")
    for fam, (m, _) in families.items():
        print(f"  {fam}: n={m['n']} hit|touch={m['hit04_given_touch']:.1f}% "
              f"tgt|touch={m['target_given_touch']:.1f}% touch={m['touch_pct']:.1f}% "
              f"dev={m['dev']} extra={m['extra']} rank={m['rank']:.3f}")

    # Save top result + a "display" variant with both entry and target rectangles
    realize_span(df, best_z)

    def dump_zones(zs: List[Zone], path: str):
        rows = []
        times = df["time"]
        for z in zs:
            t0 = times.iloc[min(z.t0, len(df) - 1)]
            t1 = times.iloc[min(z.t1, len(df) - 1)]
            rows.append({
                "id": z.zone_id,
                "dir": z.direction,
                "t0": t0.isoformat(),
                "t1": t1.isoformat(),
                "i0": int(z.t0),
                "i1": int(z.t1),
                "lo": round(z.z_low, 3),
                "hi": round(z.z_high, 3),
                "mid": round(z.z_mid, 3),
                "tlo": round(z.target_low, 3),
                "thi": round(z.target_high, 3),
                "tmid": round(z.target_mid, 3),
                "exp": round(z.expected_pct, 3),
                "score": round(z.score, 4),
                "model": z.model,
            })
        with open(path, "w") as f:
            json.dump(rows, f)
        print("wrote", path, "n=", len(rows))

    dump_zones(best_z, os.path.join(OUT_DIR, "best_zones.json"))
    with open(os.path.join(OUT_DIR, "best_metrics.json"), "w") as f:
        json.dump(best_m, f, indent=2)

    # Also store top-3 unique models for the UI toggle
    seen = set()
    catalog = []
    for m, zs in grid:
        key = m["model"]
        if key in seen:
            continue
        seen.add(key)
        realize_span(df, zs)
        dump_zones(zs, os.path.join(OUT_DIR, f"zones_{key}.json"))
        catalog.append(m)
        if len(seen) >= 4:
            break
    with open(os.path.join(OUT_DIR, "catalog.json"), "w") as f:
        json.dump(catalog, f, indent=2)

    # compact candles
    t0 = pd.Timestamp(df["time"].iloc[0])
    payload = {
        "t0": t0.isoformat(),
        "bar_min": 5,
        "t": ((df["time"] - t0).dt.total_seconds() / 60.0).round().astype(int).tolist(),
        "o": (df["open"] * 10).round().astype(int).tolist(),
        "h": (df["high"] * 10).round().astype(int).tolist(),
        "l": (df["low"] * 10).round().astype(int).tolist(),
        "c": (df["close"] * 10).round().astype(int).tolist(),
        "v": df["volume"].astype(int).tolist(),
    }
    with open(os.path.join(OUT_DIR, "candles.json"), "w") as f:
        json.dump(payload, f, separators=(",", ":"))
    print("candles bytes", os.path.getsize(os.path.join(OUT_DIR, "candles.json")))

    # leaderboard
    lb = [m for m, _ in grid]
    with open(os.path.join(OUT_DIR, "leaderboard.json"), "w") as f:
        json.dump(lb, f, indent=2)
    print("done", len(lb), "configs")


if __name__ == "__main__":
    main()
