import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B1WC-tJe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function px(tenths) {
	return tenths / 10;
}
function candleTime(pack, i) {
	const t0 = new Date(pack.t0);
	return new Date(t0.getTime() + pack.t[i] * 6e4);
}
function ohlc(pack, i) {
	return {
		t: candleTime(pack, i),
		o: px(pack.o[i]),
		h: px(pack.h[i]),
		l: px(pack.l[i]),
		c: px(pack.c[i]),
		v: pack.v[i]
	};
}
async function loadMarket() {
	const [candles, zones, metrics] = await Promise.all([
		fetch("/data/candles.json").then((r) => {
			if (!r.ok) throw new Error("Failed to load candles");
			return r.json();
		}),
		fetch("/data/zones.json").then((r) => {
			if (!r.ok) throw new Error("Failed to load zones");
			return r.json();
		}),
		fetch("/data/metrics.json").then((r) => {
			if (!r.ok) throw new Error("Failed to load metrics");
			return r.json();
		})
	]);
	return {
		candles,
		zones,
		metrics
	};
}
function formatPx(n, digits = 1) {
	return n.toLocaleString("ru-RU", {
		minimumFractionDigits: digits,
		maximumFractionDigits: digits
	});
}
function formatPct(n, digits = 1) {
	return `${n > 0 ? "+" : ""}${n.toFixed(digits)}%`;
}
function formatWhen(d) {
	return `${String(d.getDate()).padStart(2, "0")}.${String(d.getMonth() + 1).padStart(2, "0")} ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}
var RANGE_PRESETS = [
	{
		id: "1D",
		bars: 220,
		label: "1D"
	},
	{
		id: "5D",
		bars: 1100,
		label: "5D"
	},
	{
		id: "1M",
		bars: 4500,
		label: "1M"
	},
	{
		id: "3M",
		bars: 14e3,
		label: "3M"
	},
	{
		id: "6M",
		bars: 28e3,
		label: "6M"
	},
	{
		id: "ALL",
		bars: 0,
		label: "All"
	}
];
var PAD = {
	l: 8,
	r: 64,
	t: 12,
	b: 44,
	vol: 52
};
function readPalette(el) {
	const s = getComputedStyle(el);
	const v = (name, fb) => s.getPropertyValue(name).trim() || fb;
	return {
		bg: v("--color-bg", "#0c0d0f"),
		surface: v("--color-surface", "#141518"),
		fg: v("--color-fg", "#e8e6e1"),
		muted: v("--color-muted", "#8b8d93"),
		line: v("--color-line", "rgba(232,230,225,0.1)"),
		buy: v("--color-buy", "#2f9d6a"),
		sell: v("--color-sell", "#d15a4a"),
		accent: v("--color-accent", "#c5c8ce")
	};
}
function hexAlpha(hex, a) {
	const h = hex.trim();
	if (h.startsWith("rgb")) return h.replace("rgb(", "rgba(").replace(")", `, ${a})`);
	const m = /^#?([0-9a-f]{6})$/i.exec(h);
	if (!m) return hex;
	const n = parseInt(m[1], 16);
	return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${a})`;
}
function NvtkChart({ pack, zones, start, end, showBuy, showSell, onRange }) {
	const wrapRef = (0, import_react.useRef)(null);
	const canvasRef = (0, import_react.useRef)(null);
	const hoverRef = (0, import_react.useRef)(null);
	const state = (0, import_react.useRef)({
		start,
		end,
		hover: -1,
		drag: false,
		lastX: 0,
		pal: null
	});
	const onRangeRef = (0, import_react.useRef)(onRange);
	onRangeRef.current = onRange;
	state.current.start = start;
	state.current.end = end;
	const n = pack.c.length;
	const draw = (0, import_react.useCallback)(() => {
		const canvas = canvasRef.current;
		const wrap = wrapRef.current;
		if (!canvas || !wrap) return;
		const pal = state.current.pal ?? (state.current.pal = readPalette(wrap));
		const dpr = Math.min(2, window.devicePixelRatio || 1);
		const w = wrap.clientWidth;
		const h = wrap.clientHeight;
		if (w < 40 || h < 40) return;
		if (canvas.width !== Math.floor(w * dpr) || canvas.height !== Math.floor(h * dpr)) {
			canvas.width = Math.floor(w * dpr);
			canvas.height = Math.floor(h * dpr);
			canvas.style.width = `${w}px`;
			canvas.style.height = `${h}px`;
		}
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		ctx.clearRect(0, 0, w, h);
		ctx.fillStyle = pal.bg;
		ctx.fillRect(0, 0, w, h);
		const i0 = Math.max(0, Math.min(state.current.start, n - 2));
		const i1 = Math.max(i0 + 2, Math.min(n, state.current.end));
		const vis = i1 - i0;
		const plotW = w - PAD.l - PAD.r;
		const plotH = h - PAD.t - PAD.b - PAD.vol;
		const volTop = PAD.t + plotH + 8;
		const volH = PAD.vol - 16;
		if (plotW < 20 || plotH < 20) return;
		const bucket = Math.max(1, Math.ceil(vis / 1600));
		let minP = Infinity;
		let maxP = -Infinity;
		let maxV = 1;
		for (let i = i0; i < i1; i += bucket) {
			let hh = pack.h[i] / 10;
			let ll = pack.l[i] / 10;
			let vv = pack.v[i];
			for (let k = i + 1; k < i + bucket && k < i1; k++) {
				hh = Math.max(hh, pack.h[k] / 10);
				ll = Math.min(ll, pack.l[k] / 10);
				vv += pack.v[k];
			}
			if (hh > maxP) maxP = hh;
			if (ll < minP) minP = ll;
			if (vv > maxV) maxV = vv;
		}
		for (const z of zones) {
			if (z.i1 < i0 || z.i0 > i1) continue;
			if (z.dir === "BUY" && !showBuy) continue;
			if (z.dir === "SELL" && !showSell) continue;
			minP = Math.min(minP, z.lo, z.tlo);
			maxP = Math.max(maxP, z.hi, z.thi);
		}
		const padP = (maxP - minP) * .08 || 1;
		minP -= padP;
		maxP += padP;
		const span = maxP - minP || 1;
		const xAt = (idx) => PAD.l + (idx - i0) / vis * plotW;
		const yAt = (p) => PAD.t + (maxP - p) / span * plotH;
		ctx.strokeStyle = pal.line;
		ctx.lineWidth = 1;
		const ticks = 6;
		ctx.font = "11px IBM Plex Mono, ui-monospace, monospace";
		ctx.fillStyle = pal.muted;
		ctx.textAlign = "left";
		ctx.textBaseline = "middle";
		for (let t = 0; t <= ticks; t++) {
			const p = maxP - span * t / ticks;
			const y = yAt(p);
			ctx.beginPath();
			ctx.moveTo(PAD.l, y);
			ctx.lineTo(w - PAD.r, y);
			ctx.stroke();
			ctx.fillText(formatPx(p), w - PAD.r + 8, y);
		}
		ctx.textAlign = "center";
		ctx.textBaseline = "top";
		const labelEvery = Math.max(1, Math.round(vis / 6));
		let lastDay = "";
		for (let i = i0; i < i1; i += labelEvery) {
			const d = candleTime(pack, i);
			const day = `${d.getDate()}.${String(d.getMonth() + 1).padStart(2, "0")}`;
			const label = day !== lastDay ? `${day} ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}` : `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
			lastDay = day;
			ctx.fillText(label, xAt(i), h - PAD.b + 10);
		}
		const drawRect = (za, zb, lo, hi, color, strong) => {
			const x = xAt(Math.max(za, i0));
			const x2 = xAt(Math.min(zb, i1));
			const y = yAt(hi);
			const y2 = yAt(lo);
			const rw = Math.max(2, x2 - x);
			const rh = Math.max(2, y2 - y);
			ctx.fillStyle = hexAlpha(color, strong ? .22 : .13);
			ctx.fillRect(x, y, rw, rh);
			ctx.strokeStyle = hexAlpha(color, strong ? .85 : .45);
			ctx.lineWidth = strong ? 1.4 : 1;
			ctx.strokeRect(x + .5, y + .5, rw, rh);
		};
		for (const z of zones) {
			if (z.i1 < i0 || z.i0 > i1) continue;
			const strong = Boolean(z.hit04);
			if (z.dir === "BUY") {
				if (showBuy) drawRect(z.i0, z.i1, z.lo, z.hi, pal.buy, strong);
				if (showSell) drawRect(z.i0, z.i1, z.tlo, z.thi, pal.sell, Boolean(z.hit_target));
			} else {
				if (showSell) drawRect(z.i0, z.i1, z.lo, z.hi, pal.sell, strong);
				if (showBuy) drawRect(z.i0, z.i1, z.tlo, z.thi, pal.buy, Boolean(z.hit_target));
			}
		}
		const cw = Math.max(1.2, plotW / vis * bucket * .7);
		for (let i = i0; i < i1; i += bucket) {
			let oo = pack.o[i] / 10;
			let hh = pack.h[i] / 10;
			let ll = pack.l[i] / 10;
			let cc = pack.c[Math.min(i1 - 1, i + bucket - 1)] / 10;
			let vv = pack.v[i];
			for (let k = i + 1; k < i + bucket && k < i1; k++) {
				hh = Math.max(hh, pack.h[k] / 10);
				ll = Math.min(ll, pack.l[k] / 10);
				vv += pack.v[k];
				cc = pack.c[k] / 10;
			}
			const x = xAt(i + bucket / 2);
			const up = cc >= oo;
			ctx.strokeStyle = up ? pal.buy : pal.sell;
			ctx.fillStyle = up ? pal.buy : pal.sell;
			ctx.lineWidth = 1;
			ctx.beginPath();
			ctx.moveTo(x, yAt(hh));
			ctx.lineTo(x, yAt(ll));
			ctx.stroke();
			const yb = yAt(Math.max(oo, cc));
			const body = Math.max(1, Math.abs(yAt(oo) - yAt(cc)));
			ctx.fillRect(x - cw / 2, yb, cw, body);
			const vh = vv / maxV * volH;
			ctx.globalAlpha = .45;
			ctx.fillRect(x - cw / 2, volTop + volH - vh, cw, vh);
			ctx.globalAlpha = 1;
		}
		const hi = state.current.hover;
		if (hi >= i0 && hi < i1) {
			const x = xAt(hi);
			ctx.strokeStyle = hexAlpha(pal.accent, .35);
			ctx.setLineDash([3, 3]);
			ctx.beginPath();
			ctx.moveTo(x, PAD.t);
			ctx.lineTo(x, PAD.t + plotH);
			ctx.stroke();
			ctx.setLineDash([]);
			const y = yAt(pack.c[hi] / 10);
			ctx.fillStyle = pal.accent;
			ctx.beginPath();
			ctx.arc(x, y, 2.4, 0, Math.PI * 2);
			ctx.fill();
		}
		const hoverEl = hoverRef.current;
		if (hoverEl) {
			if (hi >= 0 && hi < n) {
				const d = candleTime(pack, hi);
				const o = pack.o[hi] / 10;
				const high = pack.h[hi] / 10;
				const low = pack.l[hi] / 10;
				const c = pack.c[hi] / 10;
				const chg = (c - o) / o * 100;
				hoverEl.hidden = false;
				hoverEl.innerHTML = `<span class="text-muted">${formatWhen(d)}</span>
          <span>O ${formatPx(o)}</span>
          <span>H ${formatPx(high)}</span>
          <span>L ${formatPx(low)}</span>
          <span>C ${formatPx(c)}</span>
          <span class="${chg >= 0 ? "text-buy" : "text-sell"}">${formatPct(chg)}</span>`;
			} else hoverEl.hidden = true;
		}
	}, [
		pack,
		zones,
		n,
		showBuy,
		showSell
	]);
	(0, import_react.useEffect)(() => {
		const wrap = wrapRef.current;
		if (!wrap) return;
		const ro = new ResizeObserver(() => draw());
		ro.observe(wrap);
		draw();
		return () => ro.disconnect();
	}, [
		draw,
		start,
		end
	]);
	(0, import_react.useEffect)(() => {
		draw();
	}, [
		draw,
		start,
		end,
		showBuy,
		showSell,
		zones
	]);
	const idxFromX = (x) => {
		const wrap = wrapRef.current;
		if (!wrap) return 0;
		const plotW = wrap.clientWidth - PAD.l - PAD.r;
		const i0 = state.current.start;
		const vis = Math.max(1, state.current.end - i0);
		const rel = (x - PAD.l) / plotW;
		return Math.max(0, Math.min(n - 1, Math.floor(i0 + rel * vis)));
	};
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const onWheel = (e) => {
			e.preventDefault();
			const vis = state.current.end - state.current.start;
			const rect = canvas.getBoundingClientRect();
			const pivot = idxFromX(e.clientX - rect.left);
			const factor = e.deltaY > 0 ? 1.18 : .85;
			let next = Math.round(vis * factor);
			next = Math.max(40, Math.min(n, next));
			const ratio = vis > 0 ? (pivot - state.current.start) / vis : .5;
			let ns = Math.round(pivot - next * ratio);
			let ne = ns + next;
			if (ns < 0) {
				ne -= ns;
				ns = 0;
			}
			if (ne > n) {
				ns -= ne - n;
				ne = n;
			}
			onRangeRef.current(Math.max(0, ns), Math.min(n, ne));
		};
		canvas.addEventListener("wheel", onWheel, { passive: false });
		return () => canvas.removeEventListener("wheel", onWheel);
	}, [n]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: wrapRef,
		className: "relative h-full min-h-72 w-full overflow-hidden rounded-md bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref: canvasRef,
			className: "block h-full w-full touch-none",
			onPointerDown: (e) => {
				e.target.setPointerCapture(e.pointerId);
				state.current.drag = true;
				state.current.lastX = e.nativeEvent.offsetX;
			},
			onPointerMove: (e) => {
				const x = e.nativeEvent.offsetX;
				state.current.hover = idxFromX(x);
				if (state.current.drag) {
					const wrap = wrapRef.current;
					if (wrap) {
						const plotW = wrap.clientWidth - PAD.l - PAD.r;
						const vis = state.current.end - state.current.start;
						const dx = x - state.current.lastX;
						const db = Math.round(-dx / plotW * vis);
						if (db !== 0) {
							let ns = state.current.start + db;
							let ne = state.current.end + db;
							if (ns < 0) {
								ne -= ns;
								ns = 0;
							}
							if (ne > n) {
								ns -= ne - n;
								ne = n;
							}
							ns = Math.max(0, ns);
							onRange(ns, Math.max(ns + 2, ne));
							state.current.lastX = x;
						}
					}
				}
				draw();
			},
			onPointerUp: () => {
				state.current.drag = false;
			},
			onPointerLeave: () => {
				state.current.hover = -1;
				state.current.drag = false;
				draw();
			}
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: hoverRef,
			hidden: true,
			className: "pointer-events-none absolute left-3 top-2 flex flex-wrap gap-x-3 gap-y-1 font-mono text-xs tabular-nums text-fg"
		})]
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium select-none whitespace-nowrap rounded-sm outline-none focus-visible:ring-2 focus-visible:ring-accent/40 disabled:pointer-events-none disabled:opacity-40 transition-[background-color,color,opacity,scale] duration-150 ease-out active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:bg-fg",
			ghost: "bg-transparent text-muted hover:text-fg hover:bg-surface-2",
			outline: "bg-transparent text-fg shadow-[var(--shadow-border)] hover:bg-surface-2",
			buy: "bg-buy/15 text-buy hover:bg-buy/25",
			sell: "bg-sell/15 text-sell hover:bg-sell/25"
		},
		size: {
			sm: "h-9 px-3 text-sm",
			md: "h-10 px-3.5 text-sm",
			icon: "size-10"
		}
	},
	defaultVariants: {
		variant: "ghost",
		size: "sm"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
	ref,
	className: cn(buttonVariants({
		variant,
		size
	}), className),
	...props
}));
Button.displayName = "Button";
function lastRange(n, bars) {
	if (bars <= 0 || bars >= n) return {
		start: 0,
		end: n
	};
	return {
		start: Math.max(0, n - bars),
		end: n
	};
}
function Stat({ label, value, hint, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs font-medium tracking-wide text-muted uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("mt-1 font-mono text-lg font-medium tabular-nums leading-tight", tone === "buy" && "text-buy", tone === "sell" && "text-sell", tone === "muted" && "text-muted"),
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-0.5 text-xs text-subtle",
				children: hint
			}) : null
		]
	});
}
function ZoneRow({ z, onJump }) {
	const tone = z.dir === "BUY" ? "text-buy" : "text-sell";
	const status = !z.touched ? "no touch" : z.hit04 ? "≥0.4%" : "miss";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => onJump(z),
		className: "flex w-full items-start gap-3 rounded-sm px-2 py-2.5 text-left hover:bg-surface-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("mt-0.5 h-8 w-1 shrink-0 rounded-full", z.dir === "BUY" ? "bg-buy" : "bg-sell") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-baseline justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("font-medium", tone),
						children: z.dir === "BUY" ? "Buy zone" : "Sell zone"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-xs tabular-nums text-muted",
						children: formatPct(z.exp)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mt-0.5 block font-mono text-xs tabular-nums text-subtle",
					children: [
						formatPx(z.lo),
						"–",
						formatPx(z.hi)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mt-0.5 block text-xs text-muted",
					children: [
						formatWhen(new Date(z.t0)),
						" · ",
						status
					]
				})
			]
		})]
	});
}
function Desk({ data }) {
	const { candles, zones, metrics } = data;
	const n = candles.c.length;
	const last = ohlc(candles, n - 1);
	const prev = ohlc(candles, Math.max(0, n - 2));
	const chg = (last.c - prev.c) / prev.c * 100;
	const [tab, setTab] = (0, import_react.useState)("chart");
	const [rangeId, setRangeId] = (0, import_react.useState)("5D");
	const [start, setStart] = (0, import_react.useState)(() => lastRange(n, 1100).start);
	const [end, setEnd] = (0, import_react.useState)(n);
	const [showBuy, setShowBuy] = (0, import_react.useState)(true);
	const [showSell, setShowSell] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		const preset = RANGE_PRESETS.find((p) => p.id === rangeId);
		if (!preset) return;
		const r = lastRange(n, preset.bars);
		setStart(r.start);
		setEnd(r.end);
	}, [rangeId, n]);
	const visibleZones = (0, import_react.useMemo)(() => {
		return zones.filter((z) => z.i1 >= start && z.i0 <= end).filter((z) => z.dir === "BUY" ? showBuy : showSell).sort((a, b) => b.i0 - a.i0);
	}, [
		zones,
		start,
		end,
		showBuy,
		showSell
	]);
	const jump = (z) => {
		setTab("chart");
		const pad = 80;
		setStart(Math.max(0, z.i0 - pad));
		setEnd(Math.min(n, Math.max(z.i1 + pad, z.i0 + 220)));
	};
	const from = candleTime(candles, 0);
	const to = candleTime(candles, n - 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-line px-4 py-3 sm:px-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-[0.18em] text-muted uppercase",
							children: "Symmetry Desk"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex flex-wrap items-baseline gap-x-4 gap-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "font-sans text-2xl font-semibold tracking-tight sm:text-3xl",
									children: "NVTK"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-2xl tabular-nums",
									children: formatPx(last.c)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("font-mono text-sm tabular-nums", chg >= 0 ? "text-buy" : "text-sell"),
									children: formatPct(chg)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								"5-minute tape · ",
								from.toLocaleDateString("en-GB"),
								" – ",
								to.toLocaleDateString("en-GB"),
								" · MSK"
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex rounded-md bg-surface p-1 shadow-[var(--shadow-border)]",
						children: [
							["chart", "Chart"],
							["research", "Research"],
							["logic", "Logic"]
						].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setTab(id),
							className: cn("h-10 min-w-20 rounded-sm px-3 text-sm font-medium transition-[background-color,color] duration-150", tab === id ? "bg-surface-2 text-fg" : "text-muted hover:text-fg"),
							children: label
						}, id))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid grid-cols-2 gap-px border-b border-line bg-line sm:grid-cols-3 lg:grid-cols-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-bg px-4 py-3 sm:px-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Hit after touch",
							value: `${metrics.hit04_given_touch.toFixed(1)}%`,
							hint: "move ≥ 0.4% in zone direction",
							tone: "buy"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-bg px-4 py-3 sm:px-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Zones touched",
							value: `${metrics.touch_pct.toFixed(1)}%`,
							hint: `${metrics.touch} of ${metrics.n}`
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-bg px-4 py-3 sm:px-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Median target",
							value: formatPct(metrics.median_exp),
							hint: "projected EPA move"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-bg px-4 py-3 sm:px-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Payoff MFE/MAE",
							value: `${metrics.payoff.toFixed(2)}×`,
							hint: `MFE ${formatPct(metrics.avg_mfe)}`
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-bg px-4 py-3 sm:px-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Buy zones",
							value: String(metrics.buy),
							tone: "buy",
							hint: "green rectangles"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-bg px-4 py-3 sm:px-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Sell zones",
							value: String(metrics.sell),
							tone: "sell",
							hint: "red rectangles"
						})
					})
				]
			}),
			tab === "chart" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1 flex-col lg:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-0 min-w-0 flex-1 flex-col",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2 border-b border-line px-3 py-2 sm:px-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-1",
								children: RANGE_PRESETS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: rangeId === p.id ? "outline" : "ghost",
									onClick: () => setRangeId(p.id),
									children: p.label
								}, p.id))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: showBuy ? "buy" : "ghost",
									onClick: () => setShowBuy((v) => !v),
									children: "Buy"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: showSell ? "sell" : "ghost",
									onClick: () => setShowSell((v) => !v),
									children: "Sell"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-h-72 flex-1 p-2 sm:p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NvtkChart, {
								pack: candles,
								zones,
								start,
								end,
								showBuy,
								showSell,
								onRange: (s, e) => {
									setStart(s);
									setEnd(e);
								}
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-4 pb-3 text-xs text-subtle",
							children: "Green = buy zone at projected Wolfe point 5. Red = sell zone at the EPA / destination. Rectangles scale with impulse size. Scroll to zoom, drag to pan. Moves under ±0.4% are hidden."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "flex max-h-[42vh] w-full shrink-0 flex-col border-t border-line lg:max-h-none lg:w-80 lg:border-t-0 lg:border-l",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-b border-line px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium",
							children: "Visible zones"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [visibleZones.length, " in this window"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex-1 overflow-y-auto px-2 py-1",
						children: visibleZones.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-2 py-6 text-sm text-muted",
							children: "No ±0.4% zones in view. Zoom out or pan the tape."
						}) : visibleZones.slice(0, 80).map((z) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoneRow, {
							z,
							onJump: jump
						}, z.id))
					})]
				})]
			}) : null,
			tab === "research" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Research, { metrics }) : null,
			tab === "logic" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logic, {}) : null
		]
	});
}
function Research({ metrics }) {
	const months = Object.entries(metrics.monthly);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-4xl flex-1 px-4 py-8 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-semibold tracking-tight",
				children: "What actually predicts NVTK"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-prose text-pretty text-muted",
				children: "The original V2.6 script was an execution engine (buy-stop, trailing stop, TP1) sitting on a three-pivot ABCD projection. It was long-only, mixed trade management with pattern quality, and treated 0.80% as the first target even though typical favorable excursion on this name is closer to half a percent. The chart plotted entry triangles. None of that is how Wolfe symmetry works."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-8 space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium",
						children: "1. ABCD is not a Wolfe wave"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-pretty text-muted",
						children: "V2.6 projected D = C + (B − A) from three ZigZag pivots. A Wolfe wave needs four confirmed pivots (1-2-3-4) so the 1–3 line can project point 5 and the 1–4 line can project the EPA. Without that geometry you get a harmonic completion, not channel symmetry."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium",
						children: "2. Prediction is a zone, not a fill"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-pretty text-muted",
						children: "Stops, breakeven and trail settings change P&L; they do not change whether the pattern located a reversal. Scoring is now: after the zone is confirmed, does price visit it, and once it does, does it move at least 0.4% in the predicted direction before the zone invalidates on a close through the far edge."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium",
						children: "3. Both sides, 0.4% floor"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-pretty text-muted",
						children: "NVTK mean-reverts in both directions on 5-minute structure. The model is symmetric: falling wedges print green buy rectangles, rising wedges print red sell rectangles. Anything with expected travel under 0.4% is dropped so the chart stays honest about tradable size."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium",
						children: "4. Convergence is the filter that matters"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-pretty text-muted",
						children: "Across 96 configurations on 78,008 bars, raw ABCD at 0.60% ZigZag hit 71.7% after a touch — but it sprayed 2,919 overlapping boxes. Requiring the 1–3 and 2–4 channel to converge (true Wolfe wedge) cuts that to 579 zones with a 70.4% hit after touch. Almost the same edge, five times less noise. That is the production model."
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-10 font-medium",
				children: "Year on tape"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 overflow-x-auto rounded-md bg-surface p-1 shadow-[var(--shadow-border)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[28rem] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-xs tracking-wide text-muted uppercase",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "Month"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "Zones"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "Touched"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "Hit ≥0.4% | touch"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "font-mono tabular-nums",
						children: months.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-line",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: k
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: v.n
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: v.touch
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: cn("px-3 py-2", v.hit_given_touch >= 60 ? "text-buy" : "text-fg"),
									children: [v.hit_given_touch.toFixed(1), "%"]
								})
							]
						}, k))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-10 font-medium",
				children: "Verdict"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-prose text-pretty text-muted",
				children: "After a zone is touched, price delivers a 0.4%+ move in the predicted direction about seven times in ten (70.4% on 398 touches). About 69% of projected boxes are visited at all. Average favorable excursion is +0.49% versus −0.20% adverse (payoff 2.39×). Full EPA / destination is only reached 17% of the time — the honest product of this pattern on NVTK is a 0.4–0.8% mean-reversion bounce, not a ride to the opposite rail. Worst months (Dec 2025, Apr 2026) still held above 42%. That is a usable map of location, not a guaranteed path."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-prose text-pretty text-muted",
				children: "Baseline ABCD without Wolfe convergence is a hair more accurate on the 0.4% bounce (71.7%) and unusable on a chart. The symmetry model is the one worth drawing."
			})
		]
	});
}
function Logic() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-4xl flex-1 px-4 py-8 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-semibold tracking-tight",
				children: "Production model"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-prose text-pretty text-muted",
				children: "Causal ZigZag 0.60%, four alternating pivots, converging 1–3 / 2–4 channel, entry band around the projected point 5 (width = 0.22 × AB, clamped), opposite-color destination around the 1–4 EPA. Invalidation on close through the zone. Minimum expected travel 0.40%."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-6 overflow-x-auto rounded-md bg-surface p-4 font-mono text-xs leading-relaxed text-fg shadow-[var(--shadow-border)]",
				children: CODE
			})
		]
	});
}
var CODE = `def build_causal_zigzag(df, deviation_pct=0.60):
    """Confirm a HIGH/LOW only after a reversal of deviation_pct. No lookahead."""
    ...

def wolfe_zones(pivots, min_move=0.40, half_ratio=0.22):
    for p1, p2, p3, p4 in windows_of_four(pivots):
        if not alternating(p1, p2, p3, p4):
            continue
        # Time symmetry: project point 5 at t3 + (t3 - t1)
        t5 = t3 + (t3 - t1)
        p5 = line(p1, p3, t5)          # 1-3 trendline
        epa = line(p1, p4, t_epa)      # 1-4 EPA
        if channel_width(t4) >= channel_width(t3):
            continue                   # must converge (wedge)
        direction = "BUY" if p1.kind == "LOW" else "SELL"
        move = (epa / p5 - 1) * 100 if direction == "BUY" else (1 - epa / p5) * 100
        if move < min_move:
            continue
        width = clamp(impulse_ab * half_ratio, 0.08%, 0.45%)
        yield Zone(direction, mid=p5, low=p5-width, high=p5+width,
                   target=epa, expected=move)

# Score on 78,008 NVTK 5m bars (2025-09-23 → 2026-09-28):
#   579 zones, 297 buy / 282 sell
#   68.7% of boxes are later touched
#   70.4% of touches move ≥ 0.4% in the predicted direction
#   payoff MFE/MAE = 2.39×`;
function Home() {
	const [data, setData] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		loadMarket().then((bundle) => {
			if (live) setData(bundle);
		}).catch((err) => {
			if (live) setError(err instanceof Error ? err.message : "Load failed");
		});
		return () => {
			live = false;
		};
	}, []);
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-2 bg-bg px-6 text-center text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-lg font-semibold",
			children: "Could not load the tape"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "max-w-md text-sm text-muted",
			children: error
		})]
	});
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col justify-end bg-bg px-6 pb-16 text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-[0.18em] text-muted uppercase",
				children: "Symmetry Desk"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 text-3xl font-semibold tracking-tight",
				children: "Reading NVTK…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-md text-muted",
				children: "78 thousand 5-minute bars and Wolfe zones."
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Desk, { data });
}
//#endregion
export { Home as component };
