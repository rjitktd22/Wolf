//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cy9V3rA_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-jxTQ9tmM.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-jxTQ9tmM.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-PpsQ1_AH.js"]
	}
} });
//#endregion
export { tsrStartManifest };
