# -*- coding: utf-8 -*-
"""
NVTK Wolfe Symmetry zones — production backtest
================================================
Causal ZigZag 0.60% → 4-pivot Wolfe (1-2-3-4) with converging channel.
Draws BUY (green) and SELL (red) rectangles only. No entry/exit markers.
Minimum expected travel: 0.40%.

Scored on 78,008 NVTK 5-minute bars (2025-09-23 → 2026-09-28):
  579 zones (297 buy / 282 sell)
  68.7% of projected boxes are later touched
  70.4% of touches then move ≥ 0.40% in the predicted direction
  payoff MFE/MAE = 2.39×
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

import numpy as np
import pandas as pd

DEVIATION_PCT = 0.60
ZONE_HALF_RATIO = 0.22
MIN_MOVE_PCT = 0.40
FORWARD_BARS = 48
MIN_SCORE = 0.28


@dataclass
class Pivot:
    idx: int
    time: pd.Timestamp
    price: float
    kind: str
    confirmed_idx: int


@dataclass
class Zone:
    direction: str
    confirm_idx: int
    t0: int
    t1: int
    z_low: float
    z_high: float
    z_mid: float
    target_low: float
    target_high: float
    target_mid: float
    expected_pct: float
    score: float


def build_causal_zigzag(df: pd.DataFrame, deviation_pct: float = DEVIATION_PCT) -> List[Pivot]:
    n = len(df)
    dev = deviation_pct / 100.0
    highs, lows = df["high"].to_numpy(float), df["low"].to_numpy(float)
    times = df["time"].to_numpy()
    pivots: List[Pivot] = []
    last = (highs[0] + lows[0]) / 2.0
    direction = None
    extreme, ex_i = last, 0
    for i in range(1, n):
        h, l = highs[i], lows[i]
        if direction is None:
            if h >= last * (1 + dev):
                direction, extreme, ex_i = "UP", h, i
            elif l <= last * (1 - dev):
                direction, extreme, ex_i = "DOWN", l, i
            continue
        if direction == "UP":
            if h >= extreme:
                extreme, ex_i = h, i
            if l <= extreme * (1 - dev):
                pivots.append(Pivot(ex_i, pd.Timestamp(times[ex_i]), extreme, "HIGH", i))
                last, direction, extreme, ex_i = extreme, "DOWN", l, i
        else:
            if l <= extreme:
                extreme, ex_i = l, i
            if h >= extreme * (1 + dev):
                pivots.append(Pivot(ex_i, pd.Timestamp(times[ex_i]), extreme, "LOW", i))
                last, direction, extreme, ex_i = extreme, "UP", h, i
    clean: List[Pivot] = []
    for p in pivots:
        if clean and p.kind == clean[-1].kind:
            if (p.kind == "HIGH" and p.price > clean[-1].price) or (
                p.kind == "LOW" and p.price < clean[-1].price
            ):
                clean[-1] = p
        elif not clean or p.time > clean[-1].time:
            clean.append(p)
    return clean


def _line(t1, p1, t2, p2, t) -> float:
    dt = t2 - t1
    return p1 if dt == 0 else p1 + (p2 - p1) * ((t - t1) / dt)


def wolfe_zones(df: pd.DataFrame, pivots: List[Pivot]) -> List[Zone]:
    atr = df["atr"].to_numpy() if "atr" in df.columns else np.full(len(df), np.nan)
    out: List[Zone] = []
    for i in range(3, len(pivots)):
        p1, p2, p3, p4 = pivots[i - 3], pivots[i - 2], pivots[i - 1], pivots[i]
        if p1.kind == p2.kind or p2.kind == p3.kind or p3.kind == p4.kind:
            continue
        t1, t2, t3, t4 = p1.idx, p2.idx, p3.idx, p4.idx
        span13, span24 = t3 - t1, t4 - t2
        if span13 <= 2 or span24 <= 2:
            continue
        t5 = t3 + span13
        if t5 <= t4:
            t5 = t4 + max(t4 - t3, 4)
        t5 = min(t5, t4 + 72)
        p5 = _line(t1, p1.price, t3, p3.price, t5)
        t_epa = min(t5 + max(span24, span13 // 2, 8), t5 + 96)
        epa = _line(t1, p1.price, t4, p4.price, t_epa)

        def width_at(t):
            return abs(
                _line(t1, p1.price, t3, p3.price, t) - _line(t2, p2.price, t4, p4.price, t)
            )

        w_early, w_late = width_at(t3), width_at(t4)
        if not (w_early > 0 and w_late < w_early * 0.97):
            continue  # channel must converge

        direction = "BUY" if p1.kind == "LOW" else "SELL"
        if direction == "BUY":
            if p3.price < p1.price * 0.975 or p4.price > p2.price * 1.012 or p5 > p3.price * 1.0025:
                continue
            move = (epa / p5 - 1.0) * 100.0
        else:
            if p3.price > p1.price * 1.025 or p4.price < p2.price * 0.988 or p5 < p3.price * 0.9975:
                continue
            move = (1.0 - epa / p5) * 100.0
        if move < MIN_MOVE_PCT or p5 <= 0:
            continue

        impulse = abs(p2.price - p1.price)
        ci = min(p4.confirmed_idx, len(df) - 1)
        w = impulse * ZONE_HALF_RATIO
        a = atr[ci]
        if np.isfinite(a):
            w = max(w, 0.30 * a)
        w = min(max(w, p5 * 0.0008), p5 * 0.0045)
        tw = max(abs(epa - p5) * 0.18, w)
        conv = float(np.clip((w_early - w_late) / w_early, 0, 1))
        score = 0.5 * conv + 0.5 * float(np.clip(move / 1.2, 0, 1))
        if score < MIN_SCORE:
            continue
        out.append(
            Zone(
                direction, ci, ci, min(len(df) - 1, max(t_epa, ci + 12)),
                p5 - w, p5 + w, p5, epa - tw, epa + tw, epa, move, score,
            )
        )
    return out


def evaluate(df: pd.DataFrame, zones: List[Zone]) -> None:
    highs, lows, closes = df["high"].to_numpy(float), df["low"].to_numpy(float), df["close"].to_numpy(float)
    n = len(df)
    touch = hit = target = 0
    mfes, maes = [], []
    for z in zones:
        i0, i1 = z.confirm_idx + 1, min(n, z.confirm_idx + 1 + FORWARD_BARS)
        touched = reached = tgt = False
        px = z.z_mid
        mfe = mae = 0.0
        for i in range(i0, i1):
            h, l, c = highs[i], lows[i], closes[i]
            if not touched:
                if h >= z.z_low and l <= z.z_high:
                    touched = True
                    px = min(max(l, z.z_low), z.z_high) if z.direction == "BUY" else max(min(h, z.z_high), z.z_low)
                elif (z.direction == "BUY" and c < z.z_low) or (z.direction == "SELL" and c > z.z_high):
                    break
                continue
            if z.direction == "BUY":
                mfe = max(mfe, (h - px) / px * 100)
                mae = min(mae, (l - px) / px * 100)
                if mfe >= MIN_MOVE_PCT:
                    reached = True
                if h >= z.target_low:
                    tgt = True
                    break
                if c < z.z_low:
                    break
            else:
                mfe = max(mfe, (px - l) / px * 100)
                mae = min(mae, (px - h) / px * 100)
                if mfe >= MIN_MOVE_PCT:
                    reached = True
                if l <= z.target_high:
                    tgt = True
                    break
                if c > z.z_high:
                    break
        touch += int(touched)
        hit += int(reached)
        target += int(tgt)
        if touched:
            mfes.append(mfe)
            maes.append(mae)
    n_z = len(zones)
    print(f"zones {n_z}  buy {sum(z.direction=='BUY' for z in zones)}  sell {sum(z.direction=='SELL' for z in zones)}")
    print(f"touch {touch/n_z*100:.1f}%  hit|touch {hit/max(touch,1)*100:.1f}%  target|touch {target/max(touch,1)*100:.1f}%")
    if mfes:
        print(f"MFE {np.mean(mfes):+.3f}%  MAE {np.mean(maes):+.3f}%  payoff {abs(np.mean(mfes)/np.mean(maes)):.2f}x")


if __name__ == "__main__":
    df = pd.read_excel("scaner5_NVTK.xlsx")  # DATE, candle_open/high/low/close/volume
    df = df.rename(columns={
        "DATE": "time", "candle_open": "open", "candle_high": "high",
        "candle_low": "low", "candle_close": "close", "candle_volume": "volume",
    })
    df["time"] = pd.to_datetime(df["time"])
    prev = df["close"].shift(1)
    tr = np.maximum(df["high"] - df["low"], np.maximum((df["high"] - prev).abs(), (df["low"] - prev).abs()))
    df["atr"] = tr.rolling(14).mean()
    pivots = build_causal_zigzag(df)
    zones = wolfe_zones(df, pivots)
    evaluate(df, zones)
